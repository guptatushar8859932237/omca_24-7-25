import React, { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { AdminBaseUrl, baseu11, baseurl } from "../../Basurl/Baseurl";
import { useEffect } from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import Swal from "sweetalert2";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import { usePDF } from "react-to-pdf";
import TextField from "@mui/material/TextField";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import IconButton from "@mui/material/IconButton";
import ClearIcon from "@mui/icons-material/Clear";
import { toast, ToastContainer } from "react-toastify";
import InputAdornment from "@mui/material/InputAdornment";
import {
  MenuItem,
  Box,
  Pagination,
  Stack,
  Tabs,
  Tab,
  Dialog,
  DialogContent,
} from "@mui/material";
function TabPanel({ children, value, index }) {
  return value === index && <Box sx={{ p: 2 }}>{children}</Box>;
}

export default function Appointments() {
  const role = localStorage.getItem("Role");
    const [tabValue, setTabValue] = useState(0);
  const [appointments, setAppointments] = useState([]);
  const [searchApiData, setSearchApiData] = useState([]);
  const [page, setPage] = useState(0);
  const [pageAPP, setPageAPP] = useState(0);
const [rowsPerPageAPP] = useState(10);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [dataApp, setDataApp] = useState([]);
const fullWidth = true;
  const maxWidth = "md"; // xs | sm | md | lg | xl
    const [open, setOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [pdfRowLimit, setPdfRowLimit] = useState(null);
   const [statuddropdown, setStatuddropdown] = useState("offline");
  const [filterValue, setFilterValue] = useState("");
  const { toPDF, targetRef } = usePDF({ filename: "page.pdf" });
  const handleChange = async (e, i) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        throw new Error("Authorization token is missing");
      }
      const response = await axios.post(
        `${baseurl}update_appointment_status/${i}`,
        { status: parseInt(e.target.value) },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      if (response.status === 200 || response.status === 201) {
        Swal.fire("Success!", "Status updated successfully!", "success");
        try {
          await getAppointments(); // make sure it's awaited if it’s async
        } catch (refreshError) {
          console.error("Error refreshing appointments:", refreshError);
          toast.error("Failed to refresh appointments!");
        }
        return response.data;
      } else {
        throw new Error("Failed to update status. Please try again!");
      }
    } catch (err) {
      console.error("Full Error:", err);
      if (err.response && err.response.data && err.response.data.message) {
        toast.error(err.response.data.message);
      } else if (err.message) {
        toast.error(err.message);
      } else {
        toast.error("Something went wrong. Please try again!");
      }
    }
  };
  const getAppointments = () => {
    axios
      .get(`${baseurl}all_appointment`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        console.log(response.data);
        if (response.status === 200) {
          setAppointments(response.data.data);
          setSearchApiData(response.data.data);
        } else {
          console.error("Failed to fetch job titles:", response.data.message);
        }
      })
      .catch((error) => {
        console.error("Error fetching job titles:", error);
      });
  };
  useEffect(() => {
    getAppointments();
    getAppFromApp()
  }, []);
  const handleFilter = (event) => {
  const value = event.target.value.toLowerCase();
  setFilterValue(event.target.value);
  setPage(0); // ⭐ IMPORTANT

  if (value === "") {
    setAppointments(searchApiData);
    return;
  }

  const filterResult = searchApiData.filter((item) => {
    const enquiryId = item.patientId?.toLowerCase() || "";
    const country = item.patientName?.toLowerCase() || "";
    const Hospital_name = item.Hospital_name?.toLowerCase() || "";
    const appointement_status =
      item.appointement_status?.toLowerCase() || "";
    const appointmentId = item.appointmentId?.toLowerCase() || "";
    const disease_name = item.disease_name?.toLowerCase() || "";

    return (
      enquiryId.includes(value) ||
      Hospital_name.includes(value) ||
      appointement_status.includes(value) ||
      disease_name.includes(value) ||
      appointmentId.includes(value) ||
      country.includes(value)
    );
  });

  setAppointments(filterResult);
};

  // const handleFilter = (event) => {
  //   if (event.target.value === "") {
  //     setAppointments(searchApiData);
  //   } else {
  //     const filterResult = searchApiData.filter((item) => {
  //       const enquiryId = item.patientId?.toLowerCase() || "";
  //       const country = item.patientName?.toLowerCase() || "";
  //       const Hospital_name = item.Hospital_name?.toLowerCase() || "";
  //       const appointement_status =
  //         item.appointement_status?.toLowerCase() || "";
  //       const appointmentId = item.appointmentId?.toLowerCase() || "";
  //       const disease_name = item.disease_name?.toLowerCase() || "";
  //       const searchValue = event.target.value.toLowerCase();
  //       return (
  //         enquiryId.includes(searchValue) ||
  //         Hospital_name.includes(searchValue) ||
  //         appointement_status.includes(searchValue) ||
  //         disease_name.includes(searchValue) ||
  //         appointmentId.includes(searchValue) ||
  //         country.includes(searchValue)
  //       );
  //     });
  //     setAppointments(filterResult);
  //   }
  //   setFilterValue(event.target.value);
  // };
  // const handleClearFilter = () => {
  //   setFilterValue("");
  //   setAppointments(searchApiData);
  // };
  const handleClearFilter = () => {
  setFilterValue("");
  setAppointments(searchApiData);
  setPage(0); // ⭐ IMPORTANT
};
const handleTabChange = (_, newVal) => {
  setTabValue(newVal);

  if (newVal === 0) {
    setPage(0);     // CRM tab
  } else {
    setPageAPP(0);  // APP tab
  }
};

  const handleSampleFile = () => {
    fetch(`${baseurl}export_appointments`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    })
      .then((res) => res.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = ""; // Let browser use filename from API
        a.click();
        window.URL.revokeObjectURL(url);
      });
  };
  const downloadPdf = async () => {
    const maxRows = appointments.length || 1;
    Swal.fire({
      title: "Enter number of rows for PDF",
      input: "number",
      inputLabel: `Choose between 1 and ${maxRows}`,
      inputAttributes: {
        min: "1",
        max: maxRows.toString(),
        step: "1",
      },
      inputValue: rowsPerPage,
      showCancelButton: true,
      confirmButtonText: "Generate PDF",
    }).then((result) => {
      if (result.isConfirmed) {
        const userInput = parseInt(result.value, 10);
        if (isNaN(userInput) || userInput < 1 || userInput > maxRows) {
          Swal.fire(
            "Invalid entry",
            `Please enter a number between 1 and ${maxRows}`,
            "error"
          );
          return;
        }
        setPdfRowLimit(userInput);
        setTimeout(() => {
          toPDF();
          setPdfRowLimit(null); // reset to normal view
        }, 300);
      }
    });
  };

  //  const handleTabChange = (_, newVal) => {
  //   setTabValue(newVal);
  // };

  const getAppFromApp = async ()=>{
      try {
        const response = await axios.post(`${AdminBaseUrl}app_appointments`)
        console.log(response.data.data)
        setDataApp(response.data.data)
      } catch (error) {
        console.log(error)
      }
  }
useEffect(() => {
  setPage(0);
}, [appointments]);

useEffect(() => {
  setPageAPP(0);
}, [dataApp]);
// const handleTabChange = (_, newVal) => {
//   setTabValue(newVal);
//   setPageAPP(0); // only TAB-2 reset
// };
 const handleView = (record) => {
    setSelectedRecord(record);
    setOpen(true);
  };
const handleClose = () => setOpen(false);

 const InfoItem = ({ label, value }) => (
    <div className="">
      <h6>{label}</h6>
      <p>{value || "-"}</p>
    </div>
  );
  return (
    <>
      <div className="page-wrapper">
         <Box sx={{ borderBottom: 1, borderColor: "divider", mb: 2,marginTop:"10px" }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
       <Tab 
  label="Appointments By CRM" 
  sx={{
    fontSize: "12px",
    fontWeight: "bold",
    fontFamily: "Rubik",
    color: "##666"
  }} 
/>

          <Tab   label="Appointments By APP" 
  sx={{
    fontSize: "12px",
    fontWeight: "bold",
    fontFamily: "Rubik",
    color: "#666"
  }} />
        </Tabs>
      </Box>
         <TabPanel value={tabValue} index={0}>
       <div className="content">
          <div className="row">
            <div className="col-md-12">
              <div className="country-top">
                <div className="">
                  <h4 className="page-title mb-0">Manage Appointments</h4>
                </div>
                <div className="search-btn-main">
                  <div className="">
                    <TextField
                      sx={{ width: "100%" }}
                      className="field-count"
                      label="Search"
                      id="outlined-size-small"
                      size="small"
                      value={filterValue}
                      onChange={(e) => handleFilter(e)}
                      InputLabelProps={{ shrink: true }}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end" className="input-set">
                            {filterValue && (
                              <IconButton
                                onClick={handleClearFilter}
                                edge="end"
                              >
                                <ClearIcon />
                              </IconButton>
                            )}
                          </InputAdornment>
                        ),
                      }}
                    />
                  </div>
                  <button
                    onClick={handleSampleFile}
                    className="add-button mx-1"
                  >
                    <span>
                      <i className="fa fa-file"></i>
                    </span>
                    Export File
                  </button>
                  {role === "Admin" ? (
                    <button onClick={downloadPdf} className="add-button mx-1">
                      <span>
                        <i className="fa fa-file-pdf-o"></i>
                      </span>
                      Pdf
                    </button>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="main_content">
            <div className="row">
              <div className="col-md-12">
                <div className="table-responsive">
                  <TableContainer
                    component={Paper}
                    style={{ overflowX: "auto" }}
                    ref={targetRef}
                  >
                    <Table
                      stickyHeader
                      aria-label="sticky table"
                      className="table-no-card"
                    >
                      <TableHead>
                        <TableRow>
                          <TableCell>Sr.No.</TableCell>
                          <TableCell>Patient ID</TableCell>
                          <TableCell>Patient Name</TableCell>
                          <TableCell>Disease Name</TableCell>
                          <TableCell>Appointment ID</TableCell>
                          <TableCell>Appointment Date</TableCell>
                          <TableCell>Hospital name</TableCell>
                          <TableCell>Status</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {appointments.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={8} align="center">
                              No data found
                            </TableCell>
                          </TableRow>
                        ) : (
                          (pdfRowLimit
                            ? appointments.slice(0, pdfRowLimit)
                            : appointments.slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage
                              )
                          ).map((info, i) => (
                            <TableRow
                              role="checkbox"
                              tabIndex={-1}
                              key={info.code}
                            >
                              <TableCell>
                                {pdfRowLimit
                                  ? i + 1
                                  : pageAPP * rowsPerPageAPP + i + 1}
                              </TableCell>
                              <TableCell>{info.patientId}</TableCell>
                              <TableCell>{info.patientName}</TableCell>
                              <TableCell>{info.disease_name}</TableCell>
                              <TableCell>{info.appointmentId}</TableCell>
                              <TableCell>
                                {new Date(
                                  info.appointment_Date
                                ).toLocaleDateString("en-GB")}
                              </TableCell>
                              <TableCell>{info.Hospital_name}</TableCell>
                              <TableCell>
                                <FormControl
                                  sx={{ m: 1, minWidth: 120 }}
                                  size="small"
                                  className="cont-main"
                                >
                                  <Select
                                    value={
                                      info.appointement_status === "Follow-Up"
                                        ? 2
                                        : info.appointement_status ===
                                          "Complete"
                                        ? 3
                                        : info.appointement_status ===
                                          "Cancelled"
                                        ? 4
                                        : "Schedule"
                                    }
                                    onChange={(e) =>
                                      handleChange(e, info.appointmentId)
                                    }
                                    displayEmpty
                                    inputProps={{
                                      "aria-label": "Without label",
                                    }}
                                    className="status-direct"
                                  >
                                    <MenuItem value="Schedule" disabled>
                                      Schedule
                                    </MenuItem>
                                    <MenuItem value="2">Follow-Up</MenuItem>
                                    <MenuItem value="3"> Completed</MenuItem>
                                    <MenuItem value="4">Cancelled</MenuItem>
                                  </Select>
                                </FormControl>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                    {!pdfRowLimit && (
                      <Stack spacing={2} alignItems="end" marginTop={2}>
                        <Pagination
                          count={Math.ceil(appointments.length / rowsPerPage)}
                          page={page + 1}
                          onChange={(event, value) => setPage(value - 1)}
                          shape="rounded"
                          className="page-item"
                        />
                      </Stack>
                    )}
                  </TableContainer>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          id="delete_appointment"
          className="modal fade delete-modal"
          role="dialog"
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-body text-center">
                <img src="assets/img/sent.png" alt="" width="50" height="46" />
                <h3>Are you sure want to delete this Appointment?</h3>
                <div className="m-t-20">
                  {" "}
                  <a href="#" className="btn btn-white" data-dismiss="modal">
                    Close
                  </a>
                  <button type="submit" className="btn btn-danger">
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </TabPanel>

      {/* ---------- TAB 2 : ANOTHER PAGE ---------- */}
      <TabPanel value={tabValue} index={1}>
          <div className="main_content">
            <div className="row">
              <div className="col-md-12">
                <div className="table-responsive">
                  <TableContainer
                    component={Paper}
                    style={{ overflowX: "auto" }}
                    ref={targetRef}
                  >
                    <Table
                      stickyHeader
                      aria-label="sticky table"
                      className="table-no-card"
                    >
                      <TableHead>
                        <TableRow>
                          <TableCell>Sr.No.</TableCell>
                          <TableCell>Patient Name</TableCell>
                          <TableCell>Patient email</TableCell>
                          <TableCell>City</TableCell>
                          <TableCell>Disease  </TableCell>
                          <TableCell>Appointment Date</TableCell>
                          <TableCell>Paid Amount</TableCell>
                          <TableCell>Action</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {dataApp.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={8} align="center">
                              No data found
                            </TableCell>
                          </TableRow>
                        ) : (
                          ( 
                           dataApp.slice(
  pageAPP * rowsPerPageAPP,
  pageAPP * rowsPerPageAPP + rowsPerPageAPP
)
                          ).map((info, i) => (
                            <TableRow
                              role="checkbox"
                              tabIndex={-1}
                              key={info.code}
                            >
                              <TableCell>
                                {pdfRowLimit
                                  ? i + 1
                                  :pageAPP * rowsPerPageAPP + i + 1}
                              </TableCell>
                              <TableCell>{info.name}</TableCell>
                              <TableCell>{info.email}</TableCell>
                              <TableCell>{info.city}</TableCell>
                              <TableCell>{info.health_issue}</TableCell>
                              <TableCell>
                                {new Date(
                                  info.apt_on
                                ).toLocaleDateString("en-GB")}
                              </TableCell>
                              <TableCell>{info.paid_amount}</TableCell>
                              <TableCell>
                                <i className="fa fa-eye"   onClick={() => handleView(info)}
                      style={{cursor:"pointer"}}></i>
                              </TableCell>
                             
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                    {!pdfRowLimit && (
                      <Stack spacing={2} alignItems="end" marginTop={2}>
                      <Pagination
  count={Math.ceil(dataApp.length / rowsPerPageAPP)}
  page={pageAPP + 1}
  onChange={(event, value) => setPageAPP(value - 1)}
  shape="rounded"
  className="page-item"
/>
                      </Stack>
                    )}
                  </TableContainer>
                </div>
              </div>
            </div>
          </div>
      </TabPanel>
         <Dialog
               fullWidth={fullWidth}
               maxWidth={maxWidth}
               open={open} onClose={handleClose}
             >
               <div className="main-card-header">
                 <div className="top-fixed-hd">
                   <div className="note-hd">
                     < h6>Detail's</h6>
                   </div>
                   <div className="cross-icon" onClick={handleClose}>
                     <i className="fa-solid fa-xmark"></i>
                   </div>
                 </div>
               </div>
               <DialogContent className="main-box view-table-detail">
                 {selectedRecord && (
                   <Box>
                     <div className="row">
                       <div className="col-md-12 mb-3">
                         <div className="card">
                           <div className="card-body">
                             <div className="row">
                               <div className="col-md-4">
                                 <InfoItem label="Name" value={selectedRecord.name} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Email" value={selectedRecord.email} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Phone Number" value={selectedRecord.phone} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Appointment Type" value={selectedRecord.apt_type} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="City" value={selectedRecord.city} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Country" value={selectedRecord.country} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Doctor" value={selectedRecord.doctor} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Health Issue" value={(selectedRecord.health_issue)} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Home Visit Address" value={(selectedRecord.home_visit_address)} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Paid Amount" value={(selectedRecord.paid_amount)} />
                               </div>
                               <div className="col-md-4">
                                 <InfoItem label="Treatment" value={(selectedRecord.treatment)} />
                               </div>
                             </div>
                           </div>
                         </div>
                       </div>
                     </div>
                   </Box>
                 )}
               </DialogContent>
       
             </Dialog>
        <ToastContainer />
      </div>
    </>
  );
}
