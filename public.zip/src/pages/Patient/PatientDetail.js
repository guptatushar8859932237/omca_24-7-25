import React from "react";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useState, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import { GetPatientTreatments } from "../../reducer/PatientTreatmentSlice";
import { AddHospitalForPatient } from "../../reducer/PatientTreatmentSlice";
import { GetAllHositalData } from "../../reducer/HospitalSlice";
import { GetAllCountries, GetAllCountries2 } from "../../reducer/Countries";
import TextField from "@mui/material/TextField";
import Swal from "sweetalert2";
import Autocomplete from "@mui/material/Autocomplete";
import { AppointmentForPatient } from "../../reducer/PatientTreatmentSlice";
import { AdminBaseUrl, baseurl, image } from "../../Basurl/Baseurl";
import { GetAllTreatment } from "../../reducer/TreatmentSlice";
import { ExtraServices } from "../../reducer/PatientTreatmentSlice";
import axios from "axios";
import { AddNewTretmentPayment } from "../../reducer/PatientTreatmentSlice";
import { FaPen } from "react-icons/fa";
import { toast, ToastContainer } from "react-toastify";
import avtar from "../../img/avtarImg.jpg";
import {
  Checkbox,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

function PatientDetail() {
  const navigate = useNavigate();
  const [seekerStatus, setSeekerStatus] = React.useState({});
  const [treatmentData, setTreatmentData] = useState([]);
  const [pickuptime, setPickuptime] = useState("");
  const [vehicalnumber, setVehicalnumber] = useState("");
  const [images, setImages] = useState([]);
  const [openIndex, setOpenIndex] = useState(0);
  const [treatemntData1, setTreatemntData1] = useState([]);
  const [getAttendeDetails, setGetAttendeDetails] = useState([]);
  const [hospitalDetails, setHospitalDetails] = useState({});
  const [errors, setErrors] = useState({});
  const [drivername, setDrivername] = useState("");
  const [pharmacyadd, setPharmacyadd] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [notesID, setNotesID] = useState("");
  const [drivercontact, setDrivercontact] = useState("");
  const [fieldValue, setFieldValue] = useState("");
  const [treatmentNamePassport, setTreatmentNamePassport] = useState("");
  const [treatmentIdFilter, setTreatmentIdFilter] = useState("");
  const [value1, setValue1] = useState("");
  const [treatmntidPharmacy, setTreatmntidPharmacy] = useState("");
  const [passportDetails, setPassportDetails] = useState({});
  const [editData, setEditData] = useState(null);
  const [dataPerforma, setDataPerforma] = useState(null);
  const [edited, setEdited] = useState(false);
  const [treatMentNAem, setTreatMentNAem] = useState("");
  const [filesData, setFilesData] = useState({
    attendant_fullname: "",
    attendant_relation: "",
    attendant_contact: "",
    Attende_passport: null,
    Attende_photo: null,
  });
  const [treatmentNameHeading, setTreatmentNameHeading] = useState("");
  const [attendId, setAttendId] = useState("");
  const [dataC, setDataC] = useState("");
  const location = useLocation();
  const dispatch = useDispatch();
  const { Countries } = useSelector((state) => state.Countries);
  const { PatientTreatments, loading, error } = useSelector(
    (state) => state.PatientTreatments,
  );
  const [ispatient, setIspatient] = useState("");
  const [datedata, setDatedata] = useState("");
  const [appointmentid, setAppointmentid] = useState("");
  const [tretment, setTretment] = useState([]);
  const [undadedservice, setUndadedservice] = useState([]);
  const [Service, setService] = useState([]);
  const [statuddropdown, setStatuddropdown] = useState("offline");
  const [reportdataget, setReportdataget] = useState([]);
  const [iniData, setIniData] = useState({});
  const [open, setOpen] = React.useState(false);
  const [open1, setOpen1] = React.useState(false);
  const [open2, setOpen2] = React.useState(false);
  const [open3, setOpen3] = React.useState(false);
  const [notesModal, setNotesModal] = useState(false);
  const [openmodalCharge, setOpenmodalCharge] = useState(false);
  const [hospitalCharge, setHospitalCharge] = useState("");
  const [treatmentIdCharge, setTreatmentIdCharge] = useState("");
  const [dataImperial, setDataImperial] = useState(false);
  const [open32, setOpen32] = useState(false);
  const [editModalNotes, setEditModalNotes] = useState(false);
  const [modalEditServiceOpen, setModalEditServiceOpen] = useState(false);
  const [treatmentIDservice, setTreatmentIDservice] = useState(null);
  const [open10, setOpen10] = React.useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [noteHospital2, setNoteHospital2] = useState("");
  const [treatmentPlanPopup, setTreatmentPlanPopup] = useState(false);
  const [open5, setOpen5] = React.useState(false);
  const [note, setNote] = useState("");
  const [date, setDate] = useState();
  const [fullWidth, setFullWidth] = React.useState(true);
  const [maxWidth, setMaxWidth] = React.useState("sm");
  const [hospitalId, setHospitalId] = useState("");
  const [notesTable, setNotesTable] = useState([]);
  const [valuedata, setValuedata] = useState("");
  const [hospitalData, setHospitalData] = useState({
    hospital_id: "",
    hospital_Name: "",
  });
  const [treatmentId, setTreatmentId] = useState("");
  const [hospitalcharge, sethospitalharge] = useState("");
  const [hospitlID, setHospitlID] = useState([]);
  const [ishospitalArray, setIShospitalArray] = useState([]);
  const [note2, setNote2] = useState("");
  const [activeSubTab, setActiveSubTab] = useState("details");
  const [selectedTreatmentId, setSelectedTreatmentId] = useState(null);
  const [mainTab, setMainTab] = useState(() => {
    return localStorage.getItem("patientMainTab") || "treatment-plans";
  });
  const [date2, setDate2] = useState();
  const [appHospital, setAppHospital] = useState("");
  const [kys, setKyc] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notes, setNotes] = useState([]);
  const [dataHospital, setDataHospital] = useState([]);
  const [imagefile, setImagefile] = useState(null);
  const [treatmentIDa, setTreatmentIDa] = useState(null);
  const [enqId, setEnqId] = useState("");
  const [nodaestInput, setNodaestInput] = useState("");
  const [treatmentChargeid, setTreatmentChargeid] = useState("");
  const [gettreatmentserID, setGettreatmentserID] = useState("");
  const [pharmacyvalue, setPharmacyvalue] = useState("");
  const [serviceData, setServiceData] = useState([]);
  const [payment_details, setPayment_details] = useState([]);
  const [reportsFilered1, setReportsFilered1] = useState([]);
  const [paymentsFilered, setPaymentsFilered] = useState([]);
  const [attandantFilered, setAttandantFilered] = useState([]);
  const [selectedServices, setSelectedServices] = useState([]);
  const [appointmentTabel, setAppointmentTabel] = useState([]);
  const [chkservice, setChkservice] = useState([]);
  const [blogErr, setBlogErr] = useState(false);
  const [editPatientProfile, setEditPatientProfile] = useState(false);
  const [appointErr, setAppointErr] = useState(false);
  const [openNotes, setOpenNotes] = useState(false);
  const [oeditappp, setOeditappp] = useState(false);
  const [openPharmacyModal, setOpenPharmacyModal] = useState(false);
  const [isEditT, setIsEditT] = useState(false);
  const [treatmentuser, setTreatmentuser] = useState([]);
  const [noteErr, setNoteErr] = useState(false);
  const [data, setData] = useState({
    paid_amount: "",
    paymentMethod: "",
    payment_Date: "",
    notes: "",
  });
  const usrFount = localStorage.getItem("Role");
  useEffect(() => {
    gtdatareportsdata();
    getextraservice();
  }, []);
  useEffect(() => {
    getAttemdeData();
  }, []);
  useEffect(() => {
    getTreatmentPlan();
  }, []);
  const getextraservice = async () => {
    try {
      const response = await axios.get(`${baseurl}paid_service`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      });
      const extraServices = response.data; // 👈 cleaner
    } catch (error) {
      console.error("Error fetching extra services:", error);
      throw error;
    }
  };
  const AddpaymentOnchnage = (e) => {
    const { name, value } = e.target;
    setData({ ...data, [name]: value });
  };
  const ServiceData2 = useSelector((state) => state.Service.Service);
  const { hospital } = useSelector((state) => state.hospital);
  const { Treatment } = useSelector((state) => state.Treatment);
  useEffect(() => {
    dispatch(GetAllTreatment());
  }, [dispatch]);
  useEffect(() => {
    dispatch(GetAllHositalData());
    // console.log(error, hospital);
  }, [dispatch]);
  useEffect(() => {
    dispatch(GetAllCountries2());
    dispatch(GetPatientTreatments({ id: location.state.patientId }));
  }, [dispatch, location.state.patientId]);
  useEffect(() => {
    if (PatientTreatments) {
      setIspatient(PatientTreatments);
      console.log(PatientTreatments);
      setTretment(PatientTreatments.treatments || []);
      setKyc(PatientTreatments.Kyc_details);
      setNotes(PatientTreatments.discussionNotes);
      setPayment_details(PatientTreatments.payment_details);
      setChkservice(PatientTreatments.services);
    }
  }, [PatientTreatments]);
  // console.log(chkservice);
  const handleClose = () => {
    sethospitalharge("");
    setOpen(false);
  };
  const handleClickOpen = (e, tretmentId) => {
    setOpen(true);
    setTreatmentId(tretmentId);
  };
  const handleClose5 = () => {
    setOpen5(false);
  };
  const handleClickOpen1 = (e, tretmentId, listhospital) => {
    console.log(e, tretmentId, listhospital);
    setEdited(false);
    setOpen1(true);
    setTreatmentId(selectedTreatmentId);
    setIShospitalArray(hospitalDetails);
  };
  const handleClickOpenNotes = (e, tretmentId, listhospital) => {
    setOpen5(true);
    setOpenNotes(true);
    setTreatmentId(tretmentId);
    setIShospitalArray(listhospital);
  };
  const handleClickOpen2 = (e, tretmentId, listhospital) => {
    setOpen2(true);
  };
  useEffect(() => {
    if (dataC?.treatment_id) {
      getDataapi3(dataC);
    }
  }, [dataC]);
  const handleClickOpen3 = (e, tretmentId) => {
    setOpen3(true);
    setTreatmentId(tretmentId);
  };
  const handleClickOpenPerforma = (e, tretmentId) => {
    setOpen32(true);
    setTreatmentId(tretmentId);
  };
  useEffect(() => {
    getallPayments();
  }, [location.state.patientId]);
  const handleclosePerforma = () => {
    setOpen32(false);
  };
  const handleClickOpen10 = (e, tretmentId) => {
    setTreatmentId(tretmentId);
    setOpen10(true);
  };
  const handleClose1 = () => {
    setOpen1(false);
    setDrivername("");
    setPickuptime("");
    setNote("");
    setVehicalnumber("");
    setDate("");
  };
  const handleClose2 = () => {
    setOpen2(false);
  };
  const handleClose3 = () => {
    setOpen3(false);
  };
  const handleClose10 = () => {
    setOpen10(false);
  };
  const PatientDetailButton = (e, id) => {
    navigate("/Admin/add-patient-treatment", {
      state: {
        patient: location.state.patientId,
      },
    });
  };
  const GetActiveService = () => {
    axios
      .get(`${baseurl}get_activeServices`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setService(response.data.services);
        } else {
          console.error("Failed to fetch job titles:", response.data.message);
        }
      })
      .catch((error) => {
        console.error("Error fetching job titles:", error);
      });
  };
  useEffect(() => {
    GetActiveService();
  }, []);

  const handlesubmitdata = async () => {
    const servipostdata = {
      services: {
        serviceId: valuedata,
        price: data.price,
        startTime: datedata.start_date,
        endTime: datedata.end_date,
      },
    };
    try {
      const response = await axios.post(
        `${baseurl}patient_extra_service/${gettreatmentserID}`,
        servipostdata,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        },
      );
      if (response.data.success === true) {
        setOpenModal(false);
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        Swal.fire("Service Added successfully!", "", "success");
      }
    } catch (error) {
      const errorMessage =
        error?.response?.data?.message ||
        error?.response?.data?.error ||
        "Something went wrong!";
      Swal.fire({
        title: "Error",
        text: errorMessage,
        icon: "error",
      });
    }
  };
  useEffect(() => {
    gettreatment11();
  }, []);
  const hadnlcecEditModal = (item, treatmentId) => {
    setTreatmentIDservice(treatmentId.treatment_id);
    setModalEditServiceOpen(true);
    setData(item);
  };
  const hadnlcecEcloseeModal = () => {
    setModalEditServiceOpen(false);
  };
  const gettreatment11 = async () => {
    try {
      const response = await axios.post(`${baseurl}treatment_list`);
    } catch (error) {}
  };
  useEffect(() => {
    gettreatment();
  }, [ispatient?.patientId]);
  const gettreatment = async () => {
    try {
      const response = await axios.get(
        `${baseurl}get_patient_treatment/${ispatient?.patientId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        },
      );
      setTreatmentuser(response.data.patient_treatments, "treatment data");
    } catch (error) {
      console.error("Error fetching treatment data", error);
    }
  };

  const handlesubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;
    setIsSubmitting(true);
    setBlogErr({ hospitalcharge: false });
    // if (!hospitalcharge) {
    //   setBlogErr((prev) => ({ ...prev, hospitalcharge: true }));
    //   setIsSubmitting(false);
    //   return;
    // }
    const result = await dispatch(
      AddHospitalForPatient({
        id: location.state.patientId,
        hospitalId: hospitalId,
        treatmentId: treatmentId,
      }),
    );
    if (AddHospitalForPatient.rejected.match(result)) {
      const allErrors = result.payload; // array of backend errors
      setOpen(false);
      Swal.fire({
        title: "Error Occurred",
        html: allErrors.join("<br>"),
        icon: "error",
      }).then(() => {
        setOpen(true);
      });
      setIsSubmitting(false);
      return;
    }
    try {
      setOpen(false);
      Swal.fire("Patient assigned to Hospital successfully!", "", "success");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      setTreatmentId("");
      setNote("");
      setDate("");
      setHospitalId("");
      setBlogErr(false);
    } catch (err) {
      Swal.fire("Error!", err?.message || "An error occurred", "error");
    } finally {
      setIsSubmitting(false);
    }
  };
  const deletePaymentInvoice = async (item) => {
    console.log(item);
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger",
      },
      buttonsStyling: false,
    });
    const result = await swalWithBootstrapButtons.fire({
      title: "Are you sure?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
      reverseButtons: true,
    });
    if (result.isConfirmed) {
      try {
        const response = await axios.delete(
          `${baseurl}delete_payment/${item._id}`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
              "Content-Type": "application/json",
            },
          },
        );
        if (response.data?.success) {
          getDataapi3(selectedTreatmentId);
          dispatch(GetPatientTreatments({ id: location.state.patientId }));
          Swal.fire("Deleted!", "Payment has been deleted.", "success");
        } else {
          toast.error("Failed to delete Payment");
        }
      } catch (error) {
        console.error("Delete Payment error:", error);
        toast.error("Something went wrong");
      }
    } else if (result.dismiss === Swal.DismissReason.cancel) {
      swalWithBootstrapButtons.fire({
        title: "Cancelled",
        icon: "error",
      });
    }
  };

  const handledeleteReport = async (item) => {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger",
      },
      buttonsStyling: false,
    });
    const result = await swalWithBootstrapButtons.fire({
      title: "Are you sure?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
      reverseButtons: true,
    });
    if (result.isConfirmed) {
      try {
        const response = await axios.delete(
          `${baseurl}deleteReport/${item._id}`,
        );
        if (response.data?.success) {
          Swal.fire("Deleted!", "Report has been deleted.", "success");
          getDataapi3(selectedTreatmentId);
        } else {
          toast.error("Failed to delete report");
        }
      } catch (error) {
        console.error("Delete report error:", error);
        toast.error("Something went wrong");
      }
    } else if (result.dismiss === Swal.DismissReason.cancel) {
      swalWithBootstrapButtons.fire({
        title: "Cancelled",
        icon: "error",
      });
    }
  };
  const handlesubmitAppoint = async (e) => {
    e.preventDefault();
    const isOffline = statuddropdown === "offline";
    setAppointErr({
      note: false,
      date: false,
      drivername: false,
      vehicalnumber: false,
      drivercontact: false,
      pickuptime: false,
      hospitalcharge: false,
    });
    let hasError = false;
    if (!note) {
      setAppointErr((prev) => ({ ...prev, note: true }));
      hasError = true;
    }
    if (!date) {
      setAppointErr((prev) => ({ ...prev, date: true }));
      hasError = true;
    }
    if (!pickuptime) {
      setAppointErr((prev) => ({ ...prev, pickuptime: true }));
      hasError = true;
    }
    if (isOffline) {
      if (!drivername) {
        setAppointErr((prev) => ({ ...prev, drivername: true }));
        hasError = true;
      }
    }
    if (hasError) {
      return;
    }
    try {
      const result = await dispatch(
        AppointmentForPatient({
          patientId: location.state.patientId,
          hospitalId: hospitalData.hospital_id,
          hospital_Name: hospitalData.hospital_Name,
          treatment_id: treatmentId,
          note: note,
          mode: statuddropdown,
          appointment_Date: date,
          pickup_time: pickuptime,
          vehicle_no: vehicalnumber,
          driver_name: drivername,
          driver_contact: drivercontact,
        }),
      ).unwrap();
      getDataapi3(treatmentId);
      setOpen1(false);
      Swal.fire("Patient assigned to Appointment successfully!", "", "success");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      setTreatmentId("");
      sethospitalharge("");
      setHospitalId("");
      setNote("");
      setDate("");
      setDrivercontact("");
      setPickuptime("");
      setDrivername("");
      setVehicalnumber("");
      setAppointErr(false);
    } catch (err) {
      Swal.fire("Error!", err?.message || "An error occurred", "error");
    }
  };
  const handlesubmitAppoint111 = async (e) => {
    e.preventDefault();
    const isOffline = statuddropdown === "offline";
    setAppointErr({
      note: false,
      date: false,
    });
    let hasError = false;
    if (!note) {
      setAppointErr((prev) => ({ ...prev, note: true }));
      hasError = true;
    }
    if (!date) {
      setAppointErr((prev) => ({ ...prev, date: true }));
      hasError = true;
    }
    if (hasError) {
      return;
    }
    try {
      const result = await dispatch(
        AppointmentForPatient({
          patientId: location.state.patientId,
          hospitalId: hospitalData.hospital_id,
          hospital_Name: hospitalData.hospital_Name,
          treatment_id: treatmentId,
          note: note,
          mode: statuddropdown,
          appointment_Date: date,
        }),
      ).unwrap();
      getDataapi3(treatmentId);
      setOpen1(false);
      Swal.fire("Patient assigned to Appointment successfully!", "", "success");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      setTreatmentId("");
      sethospitalharge("");
      setHospitalId("");
      setNote("");
      setDate("");
      setDrivercontact("");
      setPickuptime("");
      setDrivername("");
      setVehicalnumber("");
      setAppointErr(false);
    } catch (err) {
      Swal.fire("Error!", err?.message || "An error occurred", "error");
    }
  };
  const getdataApi = async () => {
    try {
      const rresponse = await axios.post(`${AdminBaseUrl}hospital_list`);
      if (rresponse.data.success === "true") {
        setDataHospital(rresponse.data.data);
      }
    } catch (error) {}
  };
  useEffect(() => {
    getdataApi();
  }, []);
  const allowedTypes = [
    "image/jpeg",
    "image/png",
    "image/jpg",
    "application/pdf",
  ];
  const handleKysDetail = async (e) => {
    e.preventDefault();
    const {
      attendant_fullname,
      attendant_relation,
      attendant_contact,
      Attende_passport,
      country,
      attendant_address,
    } = filesData;
    if (
      !attendant_fullname?.trim() ||
      !attendant_relation?.trim() ||
      !attendant_contact?.trim() ||
      !country?.trim() ||
      !Attende_passport ||
      !attendant_address
    ) {
      Swal.fire("All fields are mandatory!", "", "warning");
      return;
    }
    const formData = new FormData();
    formData.append("attendant_fullname", attendant_fullname);
    formData.append("attendant_relation", attendant_relation);
    formData.append("attendant_contact", attendant_contact);
    formData.append("country", filesData.country);
    formData.append("attendant_address", attendant_address);
    filesData.Attende_passport.forEach((file) => {
      formData.append("attendant_passport", file);
    });
    console.log(filesData);
    try {
      const response = await axios.post(
        `${baseurl}addAttendeeDetails/${attendId}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      );
      if (response.data.success) {
        getDataapi3(attendId);
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        setOpen2(false);
        Swal.fire("Attendant  Details Added Successfully!", "", "success");
        setFilesData({
          attendant_fullname: "",
          attendant_relation: "",
          attendant_contact: "",
          Attende_passport: null,
          Attende_photo: null,
        });
      }
    } catch (error) {
      Swal.fire(
        "Error!",
        error?.response?.data?.message || error.message,
        "error",
      );
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFilesData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const handleFileChange = (e, fieldName) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    if (fieldName === "Attende_photo") {
      const file = files[0];
      if (!file.type.startsWith("image/")) {
        Swal.fire("Only image file allowed for Photo!", "", "warning");
        return;
      }
      setFilesData((prev) => ({
        ...prev,
        [fieldName]: file,
      }));
    } else if (fieldName === "Attende_passport") {
      const fileArray = Array.from(files);
      const validFiles = fileArray.filter(
        (file) =>
          file.type.startsWith("image/") || file.type === "application/pdf",
      );
      if (validFiles.length !== fileArray.length) {
        Swal.fire("Only images and PDF files are allowed!", "", "warning");
        return;
      }
      setFilesData((prev) => ({
        ...prev,
        [fieldName]: validFiles,
      }));
    }
  };
  const handleOnChangeCheckbox = (event, id) => {
    const selectedService = Service.find((info) => info.serviceId === id);
    if (selectedService) {
      if (event.target.checked) {
        if (!selectedServices.some((service) => service.serviceId === id)) {
          setSelectedServices((prev) => [
            ...prev,
            {
              serviceId: selectedService.serviceId,
              price: selectedService.price,
            },
          ]);
        }
        setChkservice((prev) => [...prev, selectedService]);
      } else {
        setSelectedServices((prev) =>
          prev.filter((service) => service.serviceId !== id),
        );
        setChkservice((prev) =>
          prev.filter((service) => service.serviceId !== id),
        );
      }
    }
  };
  const handleExtraService = async () => {
    const allServices = [...chkservice, ...selectedServices];
    try {
      const result = await dispatch(
        ExtraServices({ id: location.state.patientId, services: allServices }),
      ).unwrap();
      Swal.fire("New Services Added!", "", "success");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
    } catch (err) {
      Swal.fire("Error!", err?.message || "An error occurred", "error");
    }
  };
  const handleNotesdata = (e) => {
    e.preventDefault();
    setNoteErr({
      note2: false,
      date2: false,
    });
    let hasError = false;
    if (!note2) {
      setNoteErr((prev) => ({ ...prev, note2: true }));
      hasError = true;
    }
    if (!date2) {
      setNoteErr((prev) => ({ ...prev, date2: true }));
      hasError = true;
    }
    if (hasError) return;
    const formData = new FormData();
    formData.append("note", note2);
    formData.append("date", date2);
    if (images && images.length > 0) {
      images.forEach((img) => {
        formData.append("treatmentNoteImages", img); // backend should use upload.array("images")
      });
    }
    axios
      .post(`${baseurl}add_treatment_notes/${treatmentId}`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setOpen5(false);
          getDataapi3(treatmentId);
          Swal.fire("Success", "Notes added successfully!", "success");
          dispatch(GetPatientTreatments({ id: location.state.patientId }));
        }
        setNote2("");
        setDate2("");
        setImages([]); // ✅ clear images
        setNoteErr({
          note2: false,
          date2: false,
        });
      })
      .catch((error) => {
        setOpen5(false);
        Swal.fire("Error", `${error?.response?.data?.message}`, "error");
      });
  };
  const handleAddTritmentPayment = async () => {
    console.log(treatmentId, selectedTreatmentId);
    try {
      const formData = new FormData();
      formData.append("id", treatmentId || selectedTreatmentId);
      formData.append("paid_amount", data?.paid_amount);
      formData.append("notes", data?.notes);
      formData.append("paymentMethod", data?.paymentMethod);
      formData.append("payment_Date", data?.payment_Date);
      formData.append("paid_to", iniData?.paid_to);
      formData.append("paid_for", iniData?.paid_for);
      formData.append("platform", 1);
      if (iniData?.attachFile) {
        formData.append("attachFile", iniData.attachFile);
      }
      await dispatch(AddNewTretmentPayment(formData)).unwrap();
      getDataapi3(selectedTreatmentId);
      setOpen3(false);
      Swal.fire("Success!", "Payment Details Added Successfully!", "success");
      if (location.state?.patientId) {
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
      }
      setTreatmentId("");
      setData({
        paid_amount: "",
        paymentMethod: "",
        payment_Date: "",
      });
    } catch (err) {
      const errorMessage =
        typeof err === "string" ? err : err?.message || "Something went wrong";
      setOpen3(false);
      Swal.fire({
        icon: "error",
        title: "Error",
        text: errorMessage,
      }).then(() => {
        setOpen3(true);
      });
    }
  };
  const handleChange = async (event, id) => {
    const { value } = event.target;
    setSeekerStatus((prev) => ({
      ...prev,
      [id]: value,
    }));
    const token = localStorage.getItem("token");
    if (!token) {
      throw new Error("Authorization token is missing");
    }
    const response = await axios.post(
      `${baseurl}update_treatment_status/${id}`,
      { status: event.target.value },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      },
    );
    try {
      Swal.fire("Success!", "Status updated successfully!", "success");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      return response.data;
    } catch (err) {}
  };
  const handleChangeDetails = async (event, id) => {
    try {
      const { value } = event.target;
      setSeekerStatus((prev) => ({
        ...prev,
        [id]: value,
      }));
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("Authorization token is missing");
      }
      const response = await axios.post(
        `${baseurl}update_appointment_status/${id}`,
        { status: parseInt(value) },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      );
      Swal.fire("Success!", "Status updated successfully!", "success");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      return response.data;
    } catch (err) {
      console.error(err.response || err.message);
      if (err.response && err.response.data && err.response.data.message) {
        Swal.fire("Error", err.response.data.message, "error");
      } else {
        toast.error("Something went wrong. Please try again!");
      }
    }
  };
  const groupedPayments = payment_details?.reduce((acc, info) => {
    if (!acc[info.treatment_id]) {
      acc[info.treatment_id] = [];
    }
    acc[info.treatment_id].push(info);
    return acc;
  }, {});
  const penModal = (a, b) => {
    getapicall(b);
    setGettreatmentserID(b);
    setOpenModal(true);
  };
  const closeModal = () => {
    setOpenModal(false);
  };
  useEffect(() => {
    getallservice();
  }, []);
  const getallservice = async () => {
    try {
      const response = await axios.get(`${baseurl}get_activeServices`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      });
      setServiceData(response.data.services);
    } catch (error) {
      console.error("Error fetching services:", error);
    }
  };
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  const andlechange = (e) => {
    const { name, value } = e.target;
    const val1 = e.target.value;
    getapicall(val1);
    setData({ ...data, [name]: value });
    serviceData.map((info) => {
      if (info.serviceId === value) {
        setValuedata(value);
        setData({ ...data, price: info.price });
      }
    });
  };
  const andlechangedate = (e) => {
    const { name, value } = e.target;
    setDatedata({ ...datedata, [name]: value });
  };
  const getapicall = (getapicall) => {
    axios
      .get(`${baseurl}get_unadded_services_for_treatment/${getapicall}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        setUndadedservice(response.data.availableServices);
      })
      .catch((error) => {
        console.error("Error fetching unadded services:", error);
      });
  };
  const handlefilechange = (e) => {
    const { name, value } = e.target;
    setIniData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const handleFileChange12 = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png"];
    if (!allowedTypes.includes(file.type)) {
      Swal.fire("Only JPG, PNG, files are allowed.");
      return;
    }
    setImagefile(file); // store in state
  };
  const handleFileChange1 = (e) => {
    const files = Array.from(e.target.files);
    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "application/pdf",
    ];
    const validFiles = files.filter((file) => allowedTypes.includes(file.type));
    if (validFiles.length !== files.length) {
      Swal.fire("Only JPG, PNG, or PDF files are allowed.");
      return;
    }
    setImagefile(validFiles);
  };
  const handleAttachFile = (e) => {
    const file = e.target.files[0];
    setIniData((prev) => ({
      ...prev,
      attachFile: file,
    }));
  };
  const handleViewImages = (images) => {
    if (!images || images.length === 0) return;
    images.forEach((img) => {
      const url = image + img;
      window.open(url, "_blank");
    });
  };
  const handleClickSubmit = async () => {
    // 🔥 VALIDATION START
    if (!iniData.reportTitle) {
      return Swal.fire("Error", "Report Title is required", "error");
    }

    if (!iniData.treatment_report_date) {
      return Swal.fire("Error", "Report Date is required", "error");
    }

    if (!imagefile || imagefile.length === 0) {
      return Swal.fire(
        "Error",
        "At least one Treatment Report image is required",
        "error",
      );
    }
    // 🔥 VALIDATION END

    try {
      const formData = new FormData();
      formData.append("reportTitle", iniData.reportTitle);
      formData.append("treatment_report_date", iniData.treatment_report_date);
      formData.append("platform", 1);

      formData.append("attachFile", iniData.attachFile);

      imagefile.forEach((file) => {
        formData.append("treatmentReport", file);
      });

      const response = await axios.post(
        `${baseurl}addReports/${treatmentId}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );

      if (response?.data?.success) {
        Swal.fire({
          icon: "success",
          title: "Success",
          text: "Report Added Successfully!",
        });

        handleClose10();
        getDataapi3(treatmentId);
      } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: response?.data?.message || "Failed to add report",
        });
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text:
          error?.response?.data?.message ||
          "Something went wrong. Please try again.",
      });
    }
  };
  // const handleClickSubmit = async () => {
  //   try {
  //     const formData = new FormData();
  //     formData.append("reportTitle", iniData.reportTitle);
  //     formData.append("treatment_report_date", iniData.treatment_report_date);
  //     formData.append("platform", 1);
  //     if (iniData.attachFile) {
  //       formData.append("attachFile", iniData.attachFile);
  //     }
  //     imagefile.forEach((file) => {
  //       formData.append("treatmentReport", file);
  //     });
  //     const response = await axios.post(
  //       `${baseurl}addReports/${treatmentId}`,
  //       formData,
  //       {
  //         headers: {
  //           Authorization: `Bearer ${localStorage.getItem("token")}`,
  //         },
  //       },
  //     );
  //     if (response?.data?.success) {
  //       handleClose10();
  //       getDataapi3(treatmentId);
  //       Swal.fire({
  //         icon: "success",
  //         title: "Success",
  //         text: "Report Added Successfully!",
  //       });
  //       handleClose10(); // close modal
  //     } else {
  //       Swal.fire({
  //         icon: "error",
  //         title: "Error",
  //         text: response?.data?.message || "Failed to add report",
  //       });
  //     }
  //   } catch (error) {
  //     Swal.fire({
  //       icon: "error",
  //       title: "Error",
  //       text:
  //         error?.response?.data?.message ||
  //         "Something went wrong. Please try again.",
  //     });
  //   }
  // };
  const handleopenNotesModal = (id) => {
    const response = notes.filter((item) => {
      return item.id === id;
    });
    setNodaestInput(response[0]);
    setNotesModal(true);
  };
  const handleCloseNotesmodal = () => {
    setNotesModal(false);
  };
  const handlechangenotesdata = (e) => {
    const { name, value } = e.target;
    setNodaestInput({ ...nodaestInput, [name]: value });
  };
  const handleKysDetailnotes = async (e) => {
    e.preventDefault();
    try {
      const postdata = {
        id: nodaestInput.id,
        note: nodaestInput.note,
        date: nodaestInput.date,
      };
      const response = await axios.post(
        `${baseurl}update_notes/${location.state.patientId}`,
        postdata,
      );
      if (response.data.success === true) {
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        handleCloseNotesmodal();
        Swal.fire("Notes Updates Successfully!", "", "success");
      } else {
        toast.error("somethign went wornh");
      }
    } catch (error) {
      // console.log(error);
    }
  };
  const gtdatareportsdata = async () => {
    try {
      const response = await axios.get(
        `${baseurl}getReports/${location.state.patientId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        },
      );
      if (response.data.success === true) {
        setTreatmentData(response.data.data);
        setReportdataget(response.data.data);
      } else {
      }
    } catch (error) {
      // console.log("Error:", error);
    }
  };
  const handledelete = async (info) => {
    console.log(info);
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger",
      },
      buttonsStyling: false,
    });
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "This hospital will be permanently deleted!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#6e7881",
      confirmButtonText: "Yes, delete it!",
    });
    if (!result.isConfirmed) return;
    try {
      const response = await axios.delete(
        `${baseurl}deleteTreatmentHospital/${info.treatment_id}/${info.hospital.details.hospital_id}`,
      );
      if (response.data.success === true) {
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        Swal.fire({
          icon: "success",
          title: "Deleted!",
          text: "Hospital deleted successfully",
          timer: 1500,
          showConfirmButton: false,
        });
      } else {
        Swal.fire("Error", "Something went wrong", "error");
      }
    } catch (error) {
      console.error(error);
      Swal.fire("Error", "Server error occurred", "error");
    }
  };
  const editServiceandlechange = (e) => {
    const { name, value } = e.target;
    setData({ ...data, [name]: value });
  };
  const handlesubmitdataserviceEdit = async () => {
    const payload = {
      _id: data._id,
      duration: data.duration,
      endTime: data.endTime,
      price: Number(data.price),
      service_type: data.service_type,
      serviceId: data.serviceId,
      serviceName: data.serviceName,
      startTime: data.startTime,
    };
    try {
      const response = await axios.put(
        `${baseurl}edit_patient_extra_service/${treatmentIDservice}/${data.serviceId}`,
        payload, // (agar body bhejni hai)
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        },
      );
      if (response.data?.success) {
        hadnlcecEcloseeModal();
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        Swal.fire({
          icon: "success",
          title: "Updated!",
          text: response.data.message || "Service updated successfully",
        });
      } else {
        Swal.fire({
          icon: "warning",
          title: "Warning",
          text: response.data?.message || "Update failed",
        });
      }
    } catch (error) {
      const errorMessage =
        error?.response?.data?.message ||
        error?.message ||
        "Something went wrong!";
      Swal.fire({
        icon: "error",
        title: "Error",
        text: errorMessage,
        didOpen: () => {
          const swalContainer = document.querySelector(".swal2-container");
          if (swalContainer) {
            swalContainer.style.zIndex = "1500"; // MUI Dialog se zyada
          }
        },
      });
    }
  };
  const handledeltePatientserveice = async (a, b, index) => {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger",
      },
      buttonsStyling: false,
    });
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you really want to delete this service?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#d33",
      cancelButtonColor: "#6e7881",
    });
    if (!result.isConfirmed) return;
    try {
      const response = await axios.delete(
        `${baseurl}delete_patient_extra_service/${b.treatment_id}/${index}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      if (response.data?.success) {
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        Swal.fire("Deleted!", "Service Deleted Successfully", "success");
      }
    } catch (error) {
      Swal.fire(
        "Error",
        error?.response?.data?.message || "Unable to delete service",
        "error",
      );
    }
  };
  const handleclickeditfunc = (item) => {
    setAppointmentid(item.appointmentId);
    setEdited(true);
    setOpen1(true);
    setEditData(item);
    setStatuddropdown(item.mode);
    setNote(item.note || "");
    setDate(item.appointment_Date || "");
    setAppHospital({
      hospital_id: item.hospital_id,
      hospital_Name: item.hospital_Name,
    });
    if (item.mode === "offline") {
      setPickuptime(item.pickup_time || "");
      setDrivername(item.driver_name || "");
      setDrivercontact(item.driver_contact || "");
      setVehicalnumber(item.vehicle_no || "");
    } else {
      setPickuptime("");
      setDrivername("");
      setDrivercontact("");
      setVehicalnumber("");
    }
  };
  const handleClose1editapp = () => {
    setOeditappp(false);
  };
  const handleclickeditdelete = async (item) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you really want to delete this appointment?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#d33",
      cancelButtonColor: "#6e7881",
    });
    if (!result.isConfirmed) return;
    try {
      const response = await axios.delete(
        `${baseurl}delete_appointment/${item.appointmentId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      if (response.data?.success) {
        getDataapi3(selectedTreatmentId);
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        Swal.fire(
          "Deleted!",
          response.data.message || "Appointment deleted successfully",
          "success",
        );
      }
    } catch (error) {
      Swal.fire(
        "Error",
        error?.response?.data?.message || "Unable to delete appointment",
        "error",
      );
    }
  };
  const handleExtraButton = async () => {
    try {
      const formattedDate = date
        ? new Date(date).toISOString().split("T")[0]
        : "";

      // 🔥 COMMON VALIDATION (for both)
      if (!hospitalData?.hospital_id) {
        return Swal.fire("Please select hospital", "", "warning");
      }

      if (!note) {
        return Swal.fire("Note is required", "", "warning");
      }

      if (!formattedDate) {
        return Swal.fire("Date is required", "", "warning");
      }

      if (!statuddropdown) {
        return Swal.fire("Mode is required", "", "warning");
      }

      // 🔥 OFFLINE VALIDATION
      if (statuddropdown === "offline") {
        if (!pickuptime) {
          return Swal.fire("Pickup time is required", "", "warning");
        }
        if (!drivername) {
          return Swal.fire("Driver name is required", "", "warning");
        }
      }

      // 🔥 ONLINE VALIDATION (if needed add more)
      if (statuddropdown === "online") {
        // example: you can enforce something extra here
        // if (!someField) return Swal.fire("Required", "", "warning");
      }

      const payload = {
        hospitalId: hospitalData.hospital_id,
        note: note,
        appointment_Date: formattedDate,
        mode: statuddropdown,
        ...(statuddropdown === "offline" && {
          pickup_time: pickuptime,
          driver_name: drivername,
          driver_contact: drivercontact,
          vehicle_no: vehicalnumber,
        }),
      };

      console.log(payload);

      const response = await axios.put(
        `${baseurl}edit_appointment/${appointmentid}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );

      if (response?.data?.success) {
        Swal.fire("Appointment updated successfully!", "", "success");
        setOpen1(false);

        getDataapi3(selectedTreatmentId);
        dispatch(GetPatientTreatments({ id: location.state.patientId }));

        // reset
        setNote("");
        setDate("");
        setPickuptime("");
        setDrivername("");
        setDrivercontact("");
        setVehicalnumber("");
        setAppHospital(null);
        setEdited(false);
        setAppointErr(false);
      } else {
        Swal.fire("Update failed!", "", "error");
      }
    } catch (err) {
      Swal.fire(
        "Error!",
        err?.response?.data?.message || err?.message || "Something went wrong",
        "error",
      );
    }
  };
  // const handleExtraButton = async () => {
  //   try {
  //     const formattedDate = date
  //       ? new Date(date).toISOString().split("T")[0]
  //       : "";
  //     const payload = {
  //       hospitalId: hospitalData.hospital_id,
  //       note: note,
  //       appointment_Date: formattedDate, // ✅ formatted date
  //       mode: statuddropdown,
  //       ...(statuddropdown === "offline" && {
  //         pickup_time: pickuptime,
  //         driver_name: drivername,
  //         driver_contact: drivercontact,
  //         vehicle_no: vehicalnumber,
  //       }),
  //     };
  //     console.log(payload);
  //     const response = await axios.put(
  //       `${baseurl}edit_appointment/${appointmentid}`,
  //       payload,
  //       {
  //         headers: {
  //           Authorization: `Bearer ${localStorage.getItem("token")}`,
  //         },
  //       },
  //     );
  //     if (response?.data?.success) {
  //       Swal.fire("Appointment updated successfully!", "", "success");
  //       setOpen1(false);
  //       getDataapi3(selectedTreatmentId)
  //       dispatch(GetPatientTreatments({ id: location.state.patientId }));
  //       // reset form
  //       setNote("");
  //       setDate("");
  //       setPickuptime("");
  //       setDrivername("");
  //       setDrivercontact("");
  //       setVehicalnumber("");
  //       setAppHospital(null);
  //       setEdited(false);
  //       setAppointErr(false);
  //     } else {
  //       Swal.fire("Update failed!", "", "error");
  //     }
  //   } catch (err) {
  //     Swal.fire(
  //       "Error!",
  //       err?.response?.data?.message || err?.message || "Something went wrong",
  //       "error",
  //     );
  //   }
  // };
  const handleClicexportPayment = async (a, b) => {
    try {
      const response = await axios.get(`${baseurl}exportTreatmentExcel/${b}`, {
        responseType: "blob",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "treatment-payments.xlsx";
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      Swal.fire("Success", "Excel downloaded successfully!", "success");
    } catch (error) {
      Swal.fire("Error", "Failed to download excel file", "error");
    }
  };
  const EditButton = (a, b) => {
    setTreatmentIDservice(b.treatment_id);
    setEditModalNotes(true);
    setNotesID(a._id);
    setNote2(a.note);
    setDate2(new Date(a.date).toISOString().split("T")[0]);
  };
  const handleCloseEditModal = () => {
    setEditModalNotes(false);
  };
  const editNotes = async () => {
    if (!note2 || !date2) {
      Swal.fire({
        icon: "warning",
        title: "Missing Fields",
        text: "Please enter note and date",
      });
      return;
    }
    const formData = new FormData();
    formData.append("note", note2);
    formData.append("date", date2);

    // 👉 append multiple images
    images.forEach((img) => {
      formData.append("treatmentNoteImages", img);
    });
    try {
      const response = await axios.put(
        `${baseurl}edit_treatment_note/${treatmentIDservice}/${notesID}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      if (response.data.success) {
        getDataapi3(treatmentIDservice);
        Swal.fire({
          icon: "success",
          title: "Updated!",
          text: "Note updated successfully",
          timer: 1500,
          showConfirmButton: false,
        });
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        handleCloseEditModal();
      } else {
        Swal.fire({
          icon: "error",
          title: "Failed",
          text: response.data.message || "Update failed",
        });
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text:
          error.response?.data?.message ||
          "Something went wrong. Please try again",
      });
      // console.log(error);
    }
  };
  const EditDelete = async (a, b) => {
    const confirm = await Swal.fire({
      title: "Delete Note?",
      text: "Are You sure to delete this notes!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#6e7881",
      confirmButtonText: "Yes, Delete",
      cancelButtonText: "Cancel",
    });
    if (!confirm.isConfirmed) return;
    try {
      const response = await axios.delete(
        `${baseurl}delete_treatment_note/${b.treatment_id}/${a._id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      if (response.data.success) {
        Swal.fire({
          icon: "success",
          title: "Deleted!",
          text: "Note deleted successfully",
          timer: 1500,
          showConfirmButton: false,
        });

        getDataapi3(b.treatment_id);
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        handleCloseEditModal(); // or close delete modal if you have one
      } else {
        Swal.fire({
          icon: "error",
          title: "Failed",
          text: response.data.message || "Delete failed",
        });
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text:
          error.response?.data?.message ||
          "Something went wrong. Please try again",
      });
    }
  };

  const handleKeyPress = (e) => {
    if (!/[0-9]/.test(e.key)) {
      e.preventDefault();
    }
  };

  const EditFreeDelete = async (a, b, c) => {
    const confirmResult = await Swal.fire({
      title: "Are you sure?",
      text: "This extra service will be deleted permanently!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#6e7881",
      confirmButtonText: "Yes, delete it",
    });
    if (!confirmResult.isConfirmed) return;
    try {
      const response = await axios.delete(
        `${baseurl}delete_patient_extra_service/${b.treatment_id}/${c}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      if (response.data.success) {
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        Swal.fire({
          icon: "success",
          title: "Deleted!",
          text: "Extra service deleted successfully",
          timer: 1500,
          showConfirmButton: false,
        });
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
      } else {
        Swal.fire("Error", response.data.message || "Delete failed", "error");
      }
    } catch (error) {
      console.error(error);
      Swal.fire("Error", "Something went wrong!", "error");
    }
  };
  // ///////////////////////////////////////////////PlanTreatmentPopUp
  const PlanTreatmentPopUp = () => {
    setTreatmentPlanPopup(true);
  };
  const PlanTreatmentPopupClose = () => {
    setTreatmentPlanPopup(false);
  };
  const handleChangeDetails123 = (selectedCourse) => {
    if (!selectedCourse) return;
    const dataStore = selectedCourse.id;
    setHospitalFunction(dataStore);
  };
  const setHospitalFunction = async (dataStore) => {
    const payload = {
      treatment_id: dataStore,
    };
    try {
      const response = await axios.post(
        `${AdminBaseUrl}treatment_hospital_list`,
        payload,
      );
      if (response.data.success) {
        const hospitalData = response.data.data;

        const updatedList = [
          { _id: "all", name: "Select All" }, // 👈 YEH LINE ADD
          ...hospitalData,
        ];

        setHospitlID(updatedList);
      }
    } catch (error) {}
  };
  const validateForm = () => {
    const newErrors = {};
    if (!fieldValue) {
      newErrors.treatment = "Treatment is required";
    }
    if (!hospitalId || hospitalId.length === 0) {
      newErrors.hospitals = "Please select at least one hospital";
    }
    if (!images || images.length === 0) {
      newErrors.reports = "Please upload at least one report";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const uploadmultipleRecord = async () => {
    if (!validateForm()) return;
    const swalOnTop = Swal.mixin({
      customClass: {
        popup: "swal-on-top",
      },
      buttonsStyling: true,
    });
    const formData = new FormData();
    formData.append("patientObjectId", location.state.testid);
    formData.append("patientId", location.state.patientId);
    formData.append("treatment", JSON.stringify(fieldValue));
    formData.append("hospitals", JSON.stringify(hospitalId));
    formData.append("notes", value1 || "");
    images.forEach((file) => {
      formData.append("reports", file);
    });
    try {
      const response = await axios.post(
        `${baseurl}addTreatmentPlan`,
        formData,
        { headers: { "Content-Type": "multipart/form-data" } },
      );
      if (response?.data?.success) {
        getTreatmentPlan();
        setTreatmentPlanPopup(false);
        await swalOnTop.fire({
          icon: "success",
          title: "Success",
          text: response.data.message || "Treatment plan added successfully",
          confirmButtonText: "OK",
        });
        PlanTreatmentPopupClose();
        setFieldValue(null);
        setHospitalId([]);
        setValue1("");
        setImages([]);
      } else {
        await swalOnTop.fire(
          "Error",
          response?.data?.message || "Something went wrong",
          "error",
        );
      }
    } catch (error) {
      const errorMsg =
        error?.response?.data?.message ||
        error?.message ||
        "Server error occurred";

      await swalOnTop.fire("Error", errorMsg, "error");
    }
  };
  const handleAddTritmentPaymenttestsubmit = async () => {
    try {
      if (!dataPerforma) {
        Swal.fire({
          icon: "warning",
          title: "No File Selected",
          text: "Please select a Performa Invoice file first.",
        });
        return;
      }
      const formData = new FormData();
      formData.append("perfomainvoice", dataPerforma);
      const response = await axios.post(`${baseurl}performainvoice`, formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (response.data.success) {
        setOpen32(false);
        Swal.fire({
          icon: "success",
          title: "Uploaded Successfully!",
          text: response?.data?.message || "Performa Invoice uploaded.",
        });
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Upload Failed!",
        text:
          error?.response?.data?.message ||
          "Something went wrong. Please try again.",
      });
    }
  };
  const AddpaymentOnchnage123 = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const allowedTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/jpg",
      "image/webp",
    ];
    if (!allowedTypes.includes(file.type)) {
      Swal.fire("Only PDF or Image files are allowed!");
      e.target.value = null;
      return;
    }
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      Swal.fire("File size must be less than 5MB");
      e.target.value = null;
      return;
    }
    setDataPerforma((prev) => ({
      ...prev,
      perfomainvoice: file,
    }));
  };
  const getTreatmentPlan = async () => {
    const payload = {
      patientId: location.state.patientId,
    };
    try {
      const response = await axios.post(
        `${baseurl}getTreatmentPlans?patientId=${location.state.patientId}`,
      );
      if (response.data.success) {
        setTreatemntData1(response.data.data);
      }
    } catch (error) {}
  };
  const handleclickApprove = (hospitalids, b) => {};
  const approveReject = async (info, hospitalId, status) => {
    const payload = { status };
    try {
      const response = await axios.put(
        `${baseurl}updateHospitalStatus/${info._id}/${hospitalId}`,
        payload,
      );
      if (response?.data?.success) {
        await Swal.fire({
          icon: "success",
          title: "Success",
          text: `Hospitals approved successfully`,
          confirmButtonText: "OK",
        });
        getTreatmentPlan();
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
      } else {
        await Swal.fire(
          "Error",
          response?.data?.message || "Status update failed",
          "error",
        );
      }
    } catch (error) {
      const errorMsg =
        error?.response?.data?.message ||
        error?.message ||
        "Server error occurred";

      await Swal.fire("Error", errorMsg, "error");
    }
  };
  const handleclickEdAppointment = (a) => {
    navigate("/Admin/Edit-patient-treatment", {
      state: { data: a, patientid: location.state.patientId },
    });
  };
  const EditButtoneditprofile = (id) => {
    setEditPatientProfile(true);
  };
  const EditButtoneditprofileClose = () => {
    setEditPatientProfile(false);
  };
  const handleupdateProfile = async () => {
    if (!imagefile) {
      Swal.fire({
        icon: "warning",
        title: "No Image Selected",
        text: "Please select an image first.",
      });
      return;
    }
    const formData = new FormData();
    formData.append("patient_Profile", imagefile);
    try {
      const response = await axios.put(
        `${baseurl}update_patient/${location?.state?.patientId}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      if (response?.data?.success) {
        Swal.fire({
          icon: "success",
          title: "Profile Updated!",
          text: "Patient profile updated successfully.",
          timer: 2000,
          showConfirmButton: false,
        });
        EditButtoneditprofileClose();
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        setImagefile(null);
      } else {
        Swal.fire({
          icon: "error",
          title: "Update Failed",
          text: response?.data?.message || "Something went wrong",
        });
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Server Error",
        text: error?.response?.data?.message || "Something went wrong",
      });
    }
  };
  const handleclickAttandpDetails = async (id) => {
    setAttendId(id);
    // console.log(id);
    try {
      const response = await axios.get(`${baseurl}getAttendeeDetails/${id}`);
      setTreatmentNamePassport(response.data);
      if (response.data.success) {
        setPassportDetails(response.data.data);
      }
    } catch (error) {
      // console.log(error);
    }
  };

  const handkekeypreees = (e) => {
    const charCode = e.charCode;
    if (charCode < 48 || charCode > 57) {
      e.preventDefault();
    }
  };
  const handledeedit = (a, b) => {
    console.log(a, b);
    setTreatmentChargeid(a.treatment_id);
    // console.log(a, b);
    setIsEditT(true);
    setHospitalCharge({
      id: b._id,
      service_name: b.service_name,
      price: b.price,
      date: b.date ? new Date(b.date).toISOString().split("T")[0] : "",
    });
    setOpenmodalCharge(true);
    // setDataImperial(true);
  };
  const dataIwemperial = () => {
    setDataImperial(false);
  };
  const handleNothospitalchargeesdata = async () => {
    const payload = {
      hospital_charge: noteHospital2,
    };
    try {
      const response = await axios.put(
        `${baseurl}updateHospitalCharge/${treatmentIDa?.treatment_id}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );

      if (response.data.success) {
        setDataImperial(false);
        setNoteHospital2("");
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
        Swal.fire({
          icon: "success",
          title: "Updated!",
          text: "Hospital charge updated successfully.",
          timer: 2000,
          showConfirmButton: false,
        });
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: error.response?.data?.message || "Something went wrong!",
      });
    }
  };
  const getSelectedTreatmentInfo = () => {
    if (!selectedTreatmentId) return null;
    return tretment?.find((t) => t.treatment_id === selectedTreatmentId);
  };

  const handleMainTabChange = (tab) => {
    setMainTab(tab);
    localStorage.setItem("patientMainTab", tab);
    setSelectedTreatmentId(null);
    setActiveSubTab("details");
  };
  const handleAction = (e, type, info, d) => {
    console.log(e, type, info, d);
    const tId = info.treatment_id;
    const hDetails = info.hospital.details;
    setHospitalData({
      hospital_id: info.hospital.details.hospital_id,
      hospital_Name: info.hospital.details.hospital_Name,
    });
    const status = info.treatment_status;
    const treatmentName = info.treatment_name;

    setSelectedTreatmentId(tId);
    setTreatMentNAem(status);
    setTreatmentNameHeading(d);
    setTreatmentIdFilter(treatmentName);
    setHospitalDetails(hDetails);
    getDataapi3(tId);
    console.log(e, type, info, d);
    if (type === "attendant") {
      setActiveSubTab("attendant");
      handleclickAttandpDetails(tId);
    } else if (type === "payment") {
      setActiveSubTab("payment");
    } else if (type === "reports") {
      setActiveSubTab("reports");
    } else if (type === "hospital") {
      handleClickOpen(e, tId);
    } else if (type === "appointment") {
      setSelectedTreatmentId(tId);
      setActiveSubTab("appointment"); // modal (optional)
      // handleClickOpen1(e,tId,hDetails)
    } else if (type === "notes") {
      setActiveSubTab("notes"); // ✅ ADD THIS
      // modal (optional)
    } else if (type === "services") {
      penModal(info, tId);
    }
  };
  //   const handleAction = (e, type, info, d) => {
  //     console.log(e, type, info, d);
  //     const tId = info.treatment_id;
  //     const hDetails = info.Hospital_details;
  //     const status = info.treatment_status;
  //     const treatmentName = info.treatment_name;
  //     setSelectedTreatmentId(tId);
  //     setTreatMentNAem(status);
  //     setTreatmentNameHeading(d);
  //     setTreatmentIdFilter(treatmentName);
  //     console.log(tId);
  //     getDataapi3(tId);
  //     if (type === "attendant") {
  //       setActiveSubTab("attendant");
  //       handleclickAttandpDetails(tId);
  //     } else if (type === "payment") {
  //       setActiveSubTab("payment");
  //     } else if (type === "reports") {
  //       setActiveSubTab("reports");
  //     } else if (type === "hospital") {
  //       handleClickOpen(e, tId);
  //     } else if (type === "appointment") {
  //       handleClickOpen1(e,tId,hDetails)
  //     } else if (type === "notes") {
  //       handleClickOpenNotes(e, tId, hDetails);
  //     } else if (type === "services") {
  //       penModal(info, tId);
  //     }
  //   };
  const handleclickdeleteplan = async (item) => {
    try {
      const result = await Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel",
      });
      if (result.isConfirmed) {
        const response = await axios.delete(
          `${baseurl}deleteTreatmentPlan/${item._id}`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          },
        );
        if (response.data.success) {
          Swal.fire("Deleted!", "Plan deleted successfully.", "success");
          getTreatmentPlan();
        }
      }
    } catch (error) {
      console.error(error);
      Swal.fire("Error!", "Something went wrong.", "error");
    }
  };
  const handleStatusChange = async (id, status) => {
    try {
      const response = await axios.post(
        `${baseurl}update_treatment_status/${id}`,
        { status: status },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      if (response.data.success) {
        Swal.fire("Updated!", "Status changed successfully", "success");
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
      }
    } catch (error) {
      Swal.fire("Error!", "Something went wrong", "error");
    }
  };
  const getallPayments = async () => {
    try {
      const patientId = location?.state?.patientId;
      const response = await axios.get(
        `${baseurl}getAllPaymentsByPatientId/${patientId}`,
      );
      // console.log(response.data);
    } catch (error) {
      // console.log(error);
    }
  };
  //   const getDataapi3 = async (tId) => {
  //     try {
  //       const treatmentid = selectedTreatmentId || tId;
  //       const response = await axios.get(
  //         `${baseurl}getAllTreatmentData/${location.state.patientId}/${treatmentid}`,
  //       );
  //       const data = response.data.data;
  //       const normalizedAttendants = data.attendants.map((att) => {
  //         let passport = att.attendant_passport;
  //         // normalize to array
  //         if (!passport) {
  //           passport = [];
  //         } else if (Array.isArray(passport)) {
  //           passport = passport;
  //         } else if (typeof passport === "string") {
  //           try {
  //             if (passport.startsWith("[")) {
  //               passport = JSON.parse(passport);
  //             } else {
  //               passport = [passport];
  //             }
  //           } catch {
  //             passport = [passport];
  //           }
  //         } else if (typeof passport === "object") {
  //           passport = [passport];
  //         }
  //         return {
  //           ...att,
  //           attendant_passport: passport,
  //         };
  //       });
  //       console.log(data)
  //       setAppointmentTabel(data.appointment)
  //       setPaymentsFilered(data.payment_details);
  //       setReportsFilered1(data.reports);
  //       setAttandantFilered(normalizedAttendants);
  //       setNotesTable(data.notes || []);
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };

  const handleclickpharmacycharge = (info) => {
    console.log(info);
    setTreatmntidPharmacy(info.treatment_id);
    setOpenPharmacyModal(true);
    setPharmacyadd(false);
  };
  const deletepharmacy = async (info, index) => {
    console.log(info);

    // 🔥 Confirmation popup
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You want to delete this pharmacy charge!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    });

    // ❌ If user cancels → stop
    if (!result.isConfirmed) return;

    try {
      const response = await axios.delete(
        `${baseurl}deletePharmacyCharge/${info.treatment_id}`,
        {
          data: { index: index },
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      // ✅ Success Swal
      Swal.fire({
        title: "Deleted!",
        text: response?.data?.message || "Pharmacy charge deleted successfully",
        icon: "success",
      });

      // 🔄 Optional: refresh data
      // getPharmacyData();
    } catch (error) {
      console.log(error);

      // ❌ Error Swal
      Swal.fire({
        title: "Error!",
        text:
          error?.response?.data?.message ||
          "Failed to delete, please try again",
        icon: "error",
      });
    }
  };
  const handleclickpcloseacycharge = () => {
    setOpenPharmacyModal(false);
    setOpenPharmacyModal(false);
    setPharmacyadd(false);
    setPharmacyvalue(false);
  };
  const getDataapi3 = async (tId) => {
    try {
      const response = await axios.get(
        `${baseurl}getAllTreatmentData/${location.state.patientId}/${tId}`,
      );
      const data = response.data.data;
      console.log("API DATA:", data);
      const filteredAppointments = (data.appointment || []).filter(
        (item) => item.treatment_id === tId,
      );
      const filteredNotes = (data.notes || []).filter(
        (item) => item.treatment_id === tId,
      );
      const filteredReports = (data.reports || []).filter(
        (item) => item.treatmentId === tId, // reports me yeh sahi hai
      );
      const filteredPayments = (data.payment_details || []).filter(
        (item) => item.treatment_id === tId,
      );
      const filteredAttendants = (data.attendants || []).filter(
        (item) => item.treatment_id === tId,
      );
      setAppointmentTabel(filteredAppointments);
      setNotesTable(filteredNotes);
      setReportsFilered1(filteredReports);
      setPaymentsFilered(filteredPayments);
      setAttandantFilered(filteredAttendants);
    } catch (error) {
      console.log(error);
    }
  };
  const handleclickDeleteTreatment = async (treatment_id) => {
    console.log(treatment_id);
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to recover this treatment!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#6e7881",
      confirmButtonText: "Yes, delete it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const response = await axios.delete(
            `${baseurl}deleteTreatment/${treatment_id}`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            },
          );
          if (response.data.success) {
            Swal.fire("Deleted!", response.data.message, "success");
            dispatch(GetPatientTreatments({ id: location.state.patientId }));
          } else {
            Swal.fire("Error!", response.data.message, "error");
          }
        } catch (error) {
          console.error(error);
          Swal.fire("Error!", "Something went wrong", "error");
        }
      }
    });
  };
  const getAttemdeData = async () => {
    try {
      const response = await axios.get(
        `${baseurl}getAttendeeDetails/${location.state.patientId}`,
      );
      if (response.data.success) {
        setGetAttendeDetails(response.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleclickopencharge = (info) => {
    setTreatmentIdCharge(info.treatment_id);
    setOpenmodalCharge(true);
  };
  const handleclickclosecharge = () => {
    setIsEditT(false);
    setHospitalCharge("");
    setOpenmodalCharge(false);
  };
  const addhospitalChare = (e) => {
    const { name, value } = e.target;
    setHospitalCharge({ ...hospitalCharge, [name]: value });
  };
  const addchargeapiHedithspital = async () => {
    const payload = {
      charge_id: hospitalCharge.id,
      service_name: hospitalCharge.service_name,
      price: parseInt(hospitalCharge.price),
      date: hospitalCharge.date,
    };

    try {
      const response = await axios.put(
        `${baseurl}editHospitalServiceCharge/${treatmentChargeid}`,
        payload, // ✅ data goes here
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );

      console.log(response.data);
      handleclickclosecharge();
      setTreatmentChargeid("");
      setHospitalCharge("");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      // ✅ Success Swal
      Swal.fire({
        icon: "success",
        title: "Success",
        text: "Hospital charge Edit successfully!",
        confirmButtonColor: "#3085d6",
      });
    } catch (error) {
      console.log(error);

      // ❌ Error Swal
      Swal.fire({
        icon: "error",
        title: "Error",
        text: error?.response?.data?.message || "Something went wrong!",
        confirmButtonColor: "#d33",
      });
    }
  };
  const addchargeapiHospital = async () => {
    const payload = {
      service_name: hospitalCharge.service_name,
      price: hospitalCharge.price,
      date: hospitalCharge.date,
    };

    try {
      const response = await axios.post(
        `${baseurl}addHospitalCharge/${treatmentIdCharge}`,
        payload, // ✅ data goes here
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );

      console.log(response.data);
      handleclickclosecharge();
      setHospitalCharge("");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      // ✅ Success Swal
      Swal.fire({
        icon: "success",
        title: "Success",
        text: "Hospital charge added successfully!",
        confirmButtonColor: "#3085d6",
      });
    } catch (error) {
      console.log(error);

      // ❌ Error Swal
      Swal.fire({
        icon: "error",
        title: "Error",
        text: error?.response?.data?.message || "Something went wrong!",
        confirmButtonColor: "#d33",
      });
    }
  };

  const handledeedit123222 = async (info, index) => {
    console.log(info, index);

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You want to delete this hospital charge!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3b3b3b",
      confirmButtonText: "Yes, delete it!",
    });

    if (!result.isConfirmed) return;

    try {
      const response = await axios.delete(
        `${baseurl}deleteHospitalServiceCharge/${info.treatment_id}`,
        {
          data: {
            index: index, // ✅ IMPORTANT
          },
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );

      if (response?.data?.success) {
        Swal.fire({
          icon: "success",
          title: "Deleted!",
          text: "Hospital charge deleted successfully!",
        });

        // 🔥 refresh
        getDataapi3(info.treatment_id);
        dispatch(GetPatientTreatments({ id: location.state.patientId }));
      }
    } catch (error) {
      console.log(error);

      Swal.fire({
        icon: "error",
        title: "Error",
        text: error?.response?.data?.message || "Something went wrong!",
      });
    }
  };

  // pharmacy

  const addhosppharmacyhare = (e) => {
    const { name, value } = e.target;
    setPharmacyvalue({ ...pharmacyvalue, [name]: value });
  };

  const addchargeapipharmacy = async () => {
    const payload = {
      service_name: pharmacyvalue.service_name,
      price: pharmacyvalue.price,
      date: pharmacyvalue.date,
    };
    try {
      const response = await axios.post(
        `${baseurl}addPharmacyCharge/${treatmntidPharmacy}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // ✅ token added
          },
        },
      );
      getDataapi3(treatmntidPharmacy);
      setPharmacyvalue("");
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      handleclickpcloseacycharge();
      // ✅ Success
      Swal.fire({
        title: "Success!",
        text: response?.data?.message || "Charge added successfully",
        icon: "success",
      });
    } catch (error) {
      console.log(error);

      // ❌ Error
      Swal.fire({
        title: "Error!",
        text:
          error?.response?.data?.message ||
          "Something went wrong, please try again",
        icon: "error",
      });
    }
  };
  const handleeditpharmacycharge = (item, info) => {
    console.log(item, info);
    setTreatmntidPharmacy(info.treatment_id);
    setOpenPharmacyModal(true);
    setPharmacyadd(true);
    setPharmacyvalue({
      service_name: item.service_name,
      price: item.price,
      date: item.date ? item.date.split("T")[0] : "",
      _id: item._id,
    });
  };

  // const editpaharmacy=async()=>{
  //   const payload={
  //  service_name: pharmacyvalue.service_name,
  //   price: pharmacyvalue.price,
  //   date: pharmacyvalue.date ? pharmacyvalue.date.split("T")[0] : "",
  //   _id:pharmacyvalue._id
  //   }
  // try {
  //   const response =await axios.put(`${baseurl}editPharmacyCharge/${treatmntidPharmacy}`,payload)
  // } catch (error) {

  // }
  // }
  const editpaharmacy = async () => {
    const payload = {
      service_name: pharmacyvalue.service_name,
      price: parseInt(pharmacyvalue.price),
      date: pharmacyvalue.date, // ✅ already YYYY-MM-DD hona chahiye
      charge_id: pharmacyvalue._id,
    };

    try {
      const response = await axios.put(
        `${baseurl}editPharmacyCharge/${treatmntidPharmacy}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        },
      );
      setPharmacyvalue("");
      setOpenPharmacyModal(false);
      setPharmacyadd(false);
      dispatch(GetPatientTreatments({ id: location.state.patientId }));
      // ✅ Success Swal
      Swal.fire({
        title: "Success!",
        text: response?.data?.message || "Pharmacy updated successfully",
        icon: "success",
      });

      // 🔄 Optional: refresh data
      // getPharmacyData();
    } catch (error) {
      console.log(error);

      // ❌ Error Swal
      Swal.fire({
        title: "Error!",
        text:
          error?.response?.data?.message ||
          "Failed to update, please try again",
        icon: "error",
      });
    }
  };
  return (
    <>
      <div className="page-wrapper">
        <div className="content">
          <div className="row">
            <div className="col-md-12">
              <h4 className="page-title">
                <span>
                  <i
                    className="fi fi-sr-angle-double-small-left"
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      window.history.back();
                    }}
                  ></i>
                </span>
                Patient Details
              </h4>
            </div>
          </div>
          <div className="main_content">
            <div className="row align-items-center">
              <div className="col-md-6">
                <div class="profile-sidebar">
                  <div class="top">
                    <form>
                      <div class="image-wrap">
                        <div class="part-img">
                          <img
                            src={
                              ispatient?.patient_Profile
                                ? `${image}${ispatient?.patient_Profile}`
                                : avtar
                            }
                            className="pro-img"
                          />
                        </div>
                        <input
                          type="file"
                          class="form-control d-none"
                          name="profile_pic"
                        />
                        <label htmlFor="profileUpload" className="edit-icon">
                          <FaPen
                            size={12}
                            onClick={(e) =>
                              EditButtoneditprofile(location.state.patientId)
                            }
                          />
                        </label>
                      </div>
                    </form>
                    <div class="part-txt">
                      <h6>{ispatient?.patient_name}</h6>
                      <p>
                        Patient ID :{" "}
                        {ispatient?.patientNumber
                          ? ispatient?.patientNumber
                          : ispatient?.patientId}
                      </p>
                      {showModal && (
                        <div className="custom-modal">
                          <div className="modal-content">
                            {/* CLOSE BUTTON */}
                            <button
                              className="close-btn"
                              onClick={() => setShowModal(false)}
                            >
                              ✖
                            </button>

                            {/* PREV BUTTON */}
                            <button
                              onClick={() =>
                                setCurrentIndex((prev) =>
                                  prev === 0
                                    ? (kys?.[0]?.id_proof?.length || 1) - 1
                                    : prev - 1,
                                )
                              }
                            >
                              ⬅
                            </button>
                            {/* FILE VIEWER */}
                            {(() => {
                              const currentFile =
                                kys?.[0]?.id_proof?.[currentIndex];
                              const fileUrl = currentFile
                                ? `https://sisccltd.com/omca_crm/${currentFile}`
                                : "";
                              const isPdf = currentFile
                                ?.toLowerCase()
                                .endsWith(".pdf");
                              if (!currentFile) {
                                return <p>No file available</p>;
                              }
                              return isPdf ? (
                                <iframe
                                  src={fileUrl}
                                  title="PDF Viewer"
                                  width="400px"
                                  height="400px"
                                  style={{ border: "none" }}
                                />
                              ) : (
                                <img
                                  src={fileUrl}
                                  alt="Document"
                                  style={{
                                    width: "400px",
                                    height: "400px",
                                    objectFit: "contain",
                                  }}
                                />
                              );
                            })()}
                            <button
                              onClick={() =>
                                setCurrentIndex((prev) =>
                                  prev === (kys?.[0]?.id_proof?.length || 1) - 1
                                    ? 0
                                    : prev + 1,
                                )
                              }
                            >
                              ➡
                            </button>
                            {(() => {
                              const currentFile =
                                kys?.[0]?.id_proof?.[currentIndex];
                              const fileUrl = currentFile
                                ? `https://sisccltd.com/omca_crm/${currentFile}`
                                : "";
                              const isPdf = currentFile
                                ?.toLowerCase()
                                .endsWith(".pdf");
                              return (
                                isPdf && (
                                  <div style={{ marginTop: "10px" }}>
                                    <a
                                      href={fileUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                    >
                                      Open PDF in new tab
                                    </a>
                                  </div>
                                )
                              );
                            })()}
                          </div>
                        </div>
                      )}
                      {kys?.[0]?.id_proof && kys[0].id_proof.length > 0 && (
                        <div className="d-flex gap-2">
                          <button
                            type="button"
                            className="viewbtn"
                            onClick={() => {
                              const files = kys[0]?.id_proof;

                              if (files && files.length > 0) {
                                setCurrentIndex(0);
                                setShowModal(true);
                              } else {
                                Swal.fire(
                                  "Error",
                                  "Document not available",
                                  "error",
                                );
                              }
                            }}
                          >
                            View Patient ID
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6 patinfomain">
                <div className="user-info-main">
                  {ispatient?.contact_no && (
                    <p>
                      <i className="fa-solid fa-phone"></i>
                      <span>{ispatient.contact_no}</span>
                    </p>
                  )}
                  <p>
                    <i class="fa-solid fa-phone"></i>
                    <span>{ispatient?.emergency_contact_no}</span>
                  </p>
                  <p>
                    <i class="fa-solid fa-envelope"></i>
                    <span>{ispatient?.email}</span>
                  </p>
                  <p>
                    Gender:<span>{ispatient?.gender}</span>
                  </p>
                  <p>
                    Age:<span>{ispatient?.age}</span>
                  </p>
                </div>
                <div className="user-info-main">
                  <p>
                    <i class="fa-solid fa-house-user"></i>
                    <span>{ispatient?.address}</span>
                  </p>
                  <p>
                    Town:<span>{ispatient?.town}</span>
                  </p>
                  <p>
                    Country:<span>{ispatient?.country}</span>
                  </p>
                  <p>
                    Patient-Status:<span>{ispatient?.patient_status}</span>
                  </p>
                  <p>
                    Passport Number:<span>{ispatient?.passport_num}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="patient-tabs">
            <ul className="nav nav-tabs nav-tabs-bottom">
              <li className="nav-item">
                <a
                  className={`nav-link ${mainTab === "treatment-plans" ? "active" : ""}`}
                  href="#about-cont123"
                  data-toggle="tab"
                  onClick={() => handleMainTabChange("treatment-plans")}
                >
                  Treatment Plans{" "}
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${mainTab === "treatment" ? "active" : ""}`}
                  href="#about-cont"
                  data-toggle="tab"
                  onClick={() => handleMainTabChange("treatment")}
                >
                  Treatment{" "}
                </a>
              </li>
              {/* <li className="nav-item">
                <a
                  className={`nav-link ${mainTab === "Attende" ? "active" : ""}`}
                  href="#attendecontent"
                  data-toggle="tab"
                  onClick={() => handleMainTabChange("Attende")}
                >
                  Attende{" "}
                </a>
              </li> */}
            </ul>
            <div className="tab-content">
              <div
                className={`tab-pane ${mainTab === "treatment-plans" ? "show active" : ""}`}
                id="about-cont123"
              >
                <div className="main-tab-hd justify-content-end">
                  <div className="">
                    <button onClick={PlanTreatmentPopUp} className="add-button">
                      <span>
                        <i className="fa fa-plus"></i>
                      </span>{" "}
                      Add Treatment Plan
                    </button>
                  </div>
                </div>
                <div className="row gx-3 gy-3">
                  <div className="col-md-12">
                    {treatemntData1?.length === 0 ? (
                      <p className="text-center">
                        No Treatment Plan Added for this patients
                      </p>
                    ) : (
                      <>
                        {treatemntData1?.map((info, index) => {
                          // console.log(info, "array data");
                          return (
                            <div className="card-box" key={index}>
                              <div className="treatment-header">
                                <div className="d-flex justify-content-between">
                                  <div>
                                    <h5>{info?.treatment?.name}</h5>
                                  </div>
                                  <div>
                                    <i
                                      onClick={() => {
                                        handleclickdeleteplan(info);
                                      }}
                                      className="fa fa-trash text-danger me-2"
                                    ></i>
                                  </div>
                                </div>
                              </div>
                              <div className="treatment-body">
                                <div className="row">
                                  <div className="col-md-6">
                                    <div className="">
                                      <h5>Hospital</h5>
                                      {info?.hospitals?.map((item, i) => (
                                        <div className="hospital-row" key={i}>
                                          <div>
                                            <span className="hospital-name">
                                              {item.name}
                                            </span>
                                            {info.isAnyHospitalApproved !==
                                              false && (
                                              <span
                                                className={`status-badge ${item.status === "Approved" ? "approved" : "pending"}`}
                                              >
                                                {item.status}
                                              </span>
                                            )}
                                          </div>
                                          {info.isAnyHospitalApproved !==
                                            true && (
                                            <button
                                              className="add-button"
                                              onClick={() =>
                                                approveReject(
                                                  info,
                                                  item.id,
                                                  "Approved",
                                                )
                                              }
                                            >
                                              Approve
                                            </button>
                                          )}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                  <div className="col-md-3">
                                    <div className="">
                                      <h5>Reports</h5>
                                      {info?.reports?.length > 0 ? (
                                        info?.reports?.map((report, index) => (
                                          <div key={index}>
                                            <a
                                              href={`${image}${report.fileName}`}
                                              target="_blank"
                                              rel="noopener noreferrer"
                                              className="report-link"
                                            >
                                              View Document
                                            </a>
                                          </div>
                                        ))
                                      ) : (
                                        <span className="text-muted">
                                          No Reports
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                  <div className="col-md-3">
                                    <div className="">
                                      <h5>Notes</h5>
                                      <p className="notes-text">
                                        {info?.notes || "No Notes Added"}
                                      </p>
                                    </div>
                                  </div>
                                  {/* <div className="col-md-2">
                                    <div className="">
                                      <h5>Action</h5>
                                      <div className="action-icon">
                                        <i
                                          className="fa-solid fa-trash"
                                          // onClick={() =>
                                          //   EditDelete(index, info)
                                          // }
                                        ></i>
                                      </div>
                                    </div>
                                  </div> */}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </>
                    )}
                  </div>
                </div>
              </div>
              <div
                className={`tab-pane ${mainTab === "treatment" ? "show active" : ""}`}
                id="about-cont"
              >
                <div>
                  <div className="main-tab-hd">
                    <div className="main-tab-hd d-flex justify-content-end w-100">
                      <button
                        onClick={PatientDetailButton}
                        className="add-button"
                      >
                        <span>
                          <i className="fa fa-plus"></i>
                        </span>{" "}
                        Add Treatment
                      </button>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12">
                      {tretment?.length === 0 ? (
                        <p className="text-center">
                          No Treatment Added for this patients
                        </p>
                      ) : (
                        <>
                          {([
                            "payment",
                            "reports",
                            "attendant",
                            "appointment",
                            "notes",
                          ].includes(activeSubTab)
                            ? tretment?.filter(
                                (item) =>
                                  item.treatment_id === selectedTreatmentId,
                              )
                            : tretment
                          )?.map((info, index) => {
                            return (
                              <div className="card-box" id="accordion">
                                <div className="treat-card">
                                  <div className="sectabmain">
                                    <div className="treat-id">
                                      <div className="mngetreatment">
                                        <h3
                                          onClick={() => {
                                            setActiveSubTab("details");
                                            setSelectedTreatmentId(
                                              info.treatment_id,
                                            );
                                          }}
                                          style={{
                                            cursor: "pointer",
                                            margin: 0,
                                          }}
                                        >
                                          {
                                            // treatmentNameHeading
                                            // === ""
                                            //   ?
                                            //   info.treatment_name
                                            //   : treatmentNameHeading
                                            activeSubTab === "details"
                                              ? info.treatment_name
                                              : treatmentIdFilter === ""
                                                ? info.treatment_name
                                                : treatmentNameHeading
                                          }{" "}
                                        </h3>
                                        <div className="action-icon">
                                          <i
                                            className="fa-solid fa-trash"
                                            onClick={() => {
                                              handleclickDeleteTreatment(
                                                info.treatment_id,
                                              );
                                            }}
                                          ></i>
                                        </div>
                                      </div>
                                      <select
                                        className="form-select form-select-sm"
                                        value={info.treatment_status || ""}
                                        onChange={(e) =>
                                          handleStatusChange(
                                            info.treatment_id,
                                            e.target.value,
                                          )
                                        }
                                      >
                                        <option value="">Select Status</option>
                                        <option value="Assigned to Hospital">
                                          Assigned to Hospital
                                        </option>
                                        <option value="In Process">
                                          In Process
                                        </option>
                                        <option value="Completed">
                                          Completed
                                        </option>
                                        <option value="Cancelled">
                                          Cancelled
                                        </option>
                                      </select>
                                    </div>
                                    <div className="accor-icon">
                                      <div className="">
                                        <ul className="nav nav-tabs treat-tabs">
                                          <li className="nav-item">
                                            <button
                                              className={`nav-link ${activeSubTab === "attendant" && selectedTreatmentId === info.treatment_id ? "active" : ""}`}
                                              onClick={(e) => {
                                                handleAction(
                                                  e,
                                                  "attendant",
                                                  info,
                                                  info.treatment_name,
                                                );
                                              }}
                                            >
                                              Add Attendant
                                            </button>
                                          </li>
                                          <li className="nav-item">
                                            <button
                                              className={`nav-link ${activeSubTab === "payment" && selectedTreatmentId === info.treatment_id ? "active" : ""}`}
                                              onClick={(e) => {
                                                handleAction(
                                                  e,
                                                  "payment",
                                                  info,
                                                  info.treatment_name,
                                                );
                                              }}
                                            >
                                              Payment Details
                                            </button>
                                          </li>
                                          <li className="nav-item">
                                            <button
                                              className={`nav-link ${activeSubTab === "reports" && selectedTreatmentId === info.treatment_id ? "active" : ""}`}
                                              onClick={(e) => {
                                                handleAction(
                                                  e,
                                                  "reports",
                                                  info,
                                                  info.treatment_name,
                                                );
                                              }}
                                            >
                                              Reports
                                            </button>
                                          </li>

                                          <li className="nav-item">
                                            <button
                                              className="nav-link"
                                              onClick={(e) =>
                                                handleAction(
                                                  e,
                                                  "appointment",
                                                  info,
                                                  info.treatment_name,
                                                )
                                              }
                                            >
                                              Appointment
                                            </button>
                                          </li>
                                          <li className="nav-item">
                                            <button
                                              className="nav-link"
                                              onClick={(e) =>
                                                handleAction(
                                                  e,
                                                  "notes",
                                                  info,
                                                  info.treatment_name,
                                                )
                                              }
                                            >
                                              Notes
                                            </button>
                                          </li>
                                          {!info?.Hospital_details?.some(
                                            (item) => item.hospital_Name,
                                          ) && (
                                            <li className="nav-item">
                                              <button
                                                className="nav-link"
                                                onClick={(e) =>
                                                  handleAction(
                                                    e,
                                                    "hospital",
                                                    info,
                                                    info.treatment_name,
                                                  )
                                                }
                                              >
                                                + Add Hospital
                                              </button>
                                            </li>
                                          )}
                                          <li className="nav-item">
                                            <button
                                              className="nav-link"
                                              onClick={(e) =>
                                                handleAction(
                                                  e,
                                                  "services",
                                                  info,
                                                  info.treatment_name,
                                                )
                                              }
                                            >
                                              + Add Services
                                            </button>
                                          </li>
                                        </ul>
                                      </div>
                                      <div
                                        className={`collapse-icon ${openIndex === index ? "rotate" : ""}`}
                                        onClick={() =>
                                          setOpenIndex(
                                            openIndex === index ? null : index,
                                          )
                                        }
                                        aria-expanded={openIndex === index}
                                      >
                                        <i className="fa-solid fa-chevron-down"></i>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div
                                  className={`collapse ${openIndex === index ? "show" : ""}`}
                                >
                                  {activeSubTab === "details" ? (
                                    <>
                                      <div className="row gx-3 gy-3">
                                        {/* for hospital separate data */}
                                        <div className="col-md-12">
                                          <div className="card customstylecard">
                                            <div className="card-header">
                                              <h6>
                                                Hospital Name:
                                                <span>
                                                  {" "}
                                                  {
                                                    info?.hospital?.details
                                                      ?.hospital_Name
                                                  }
                                                </span>{" "}
                                                <span className="text-danger">
                                                  {info?.hospital?.details
                                                    ?.hospital_Name &&
                                                    info?.hospital?.charges
                                                      ?.length === 0 && (
                                                      <i
                                                        className="fa-solid fa-trash"
                                                        onClick={() =>
                                                          handledelete(info)
                                                        }
                                                      ></i>
                                                    )}
                                                </span>
                                              </h6>
                                            </div>
                                            <div className="card-body">
                                              <div className="row gx-3 gy-3">
                                                <div className="col-md-6">
                                                  <div className="card patientreat">
                                                    <div className="card-header service-list">
                                                      <h6>Treatment</h6>
                                                    </div>
                                                    <div className="card-body">
                                                      <div className="table-responsive table-no-card">
                                                        <table className="table-card w-100">
                                                          <thead>
                                                            <tr>
                                                              <th>Name</th>
                                                              <th>Charge</th>
                                                              <th>Date</th>
                                                              <th>Time</th>
                                                              <th>Action</th>
                                                            </tr>
                                                          </thead>
                                                          <tbody>
                                                            <tr key={index}>
                                                              <td>
                                                                {info?.treatment_name ||
                                                                  "-"}
                                                              </td>
                                                              <td>
                                                                {info?.treatment_course_fee ||
                                                                  "-"}
                                                              </td>
                                                              <td>
                                                                {new Date(
                                                                  info.treatment_created_at,
                                                                ).toLocaleDateString(
                                                                  "en-GB",
                                                                )}
                                                              </td>
                                                              <td>
                                                                {info.treatment_created_at
                                                                  ? new Date(
                                                                      info.treatment_created_at,
                                                                    ).toLocaleTimeString(
                                                                      "en-US",
                                                                      {
                                                                        hour: "2-digit",
                                                                        minute:
                                                                          "2-digit",
                                                                      },
                                                                    )
                                                                  : "-"}
                                                              </td>
                                                              <td>
                                                                <div className="action-icon">
                                                                  <i
                                                                    className="fa-solid fa-pen-to-square me-2"
                                                                    style={{
                                                                      cursor:
                                                                        "pointer",
                                                                    }}
                                                                    onClick={() => {
                                                                      handleclickEdAppointment(
                                                                        info,
                                                                      );
                                                                    }}
                                                                  ></i>
                                                                  {/* {item?.hospital_Name && (
                                                                          <i className="fa-solid fa-trash" style={{ cursor: "pointer" }}
                                                                            onClick={() => handledelete(info, item)}
                                                                          ></i>
                                                                        )} */}
                                                                </div>
                                                              </td>
                                                            </tr>
                                                          </tbody>
                                                        </table>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div className="col-md-6">
                                                  <div className="card patientreat">
                                                    <div className="card-header service-list d-flex justify-content-between">
                                                      <div>
                                                        <h6>Charges</h6>
                                                      </div>
                                                      <div>
                                                        <button
                                                          className="add-button"
                                                          onClick={() => {
                                                            handleclickopencharge(
                                                              info,
                                                            );
                                                          }}
                                                        >
                                                          Add Charge
                                                        </button>
                                                      </div>
                                                    </div>
                                                    <div className="card-body">
                                                      <div className="table-responsive table-no-card">
                                                        <table className="table-card w-100">
                                                          <thead>
                                                            <tr>
                                                              <th>
                                                                Service Name
                                                              </th>
                                                              <th>Price</th>
                                                              <th>Date</th>
                                                              <th>Action</th>
                                                            </tr>
                                                          </thead>
                                                          <tbody>
                                                            {info?.hospital
                                                              ?.charges
                                                              ?.length > 0 ? (
                                                              info?.hospital?.charges?.map(
                                                                (
                                                                  item,
                                                                  index,
                                                                ) => {
                                                                  const createdAt =
                                                                    item?.date;

                                                                  return (
                                                                    <tr
                                                                      key={
                                                                        index
                                                                      }
                                                                    >
                                                                      <td>
                                                                        {item?.service_name ||
                                                                          "-"}
                                                                      </td>
                                                                      <td>
                                                                        {item?.price ||
                                                                          "-"}
                                                                      </td>
                                                                      <td>
                                                                        {createdAt
                                                                          ? new Date(
                                                                              createdAt,
                                                                            ).toLocaleDateString(
                                                                              "en-GB",
                                                                            )
                                                                          : "-"}
                                                                      </td>
                                                                      <td>
                                                                        <div className="action-icon">
                                                                          <i
                                                                            className="fa-solid fa-pen-to-square me-2"
                                                                            style={{
                                                                              cursor:
                                                                                "pointer",
                                                                            }}
                                                                            onClick={() =>
                                                                              handledeedit(
                                                                                info,
                                                                                item,
                                                                              )
                                                                            }
                                                                          ></i>

                                                                          <i
                                                                            className="fa-solid fa-trash"
                                                                            style={{
                                                                              cursor:
                                                                                "pointer",
                                                                            }}
                                                                            onClick={() =>
                                                                              handledeedit123222(
                                                                                info,
                                                                                index,
                                                                              )
                                                                            }
                                                                          ></i>
                                                                        </div>
                                                                      </td>
                                                                    </tr>
                                                                  );
                                                                },
                                                              )
                                                            ) : (
                                                              <tr>
                                                                <td
                                                                  colSpan="4"
                                                                  style={{
                                                                    textAlign:
                                                                      "center",
                                                                  }}
                                                                >
                                                                  No Data Found
                                                                </td>
                                                              </tr>
                                                            )}
                                                          </tbody>
                                                        </table>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                            <div className="card-footer">
                                              <div className="row justify-content-end">
                                                <div className="col-md-12">
                                                  <div className="total-amount">
                                                    <h6 className="mb-0">
                                                      Total Amount:
                                                    </h6>
                                                    <p>
                                                      {
                                                        info?.hospital
                                                          ?.totalAmount
                                                      }
                                                    </p>
                                                  </div>
                                                </div>
                                                <div className="col-md-12">
                                                  <div className="total-amount">
                                                    <h6 className="mb-0">
                                                      Due Amount:
                                                    </h6>
                                                    <p>
                                                      {
                                                        info?.hospital
                                                          ?.dueAmount
                                                      }
                                                    </p>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        {/* for omca services */}
                                        <div className="col-md-12">
                                          <div className="card customstylecard">
                                            <div className="card-header">
                                              <h6>OMCA</h6>
                                            </div>
                                            <div className="card-body">
                                              <div className="row gx-3 gy-3">
                                                {/* extra-service */}
                                                <div className="col-md-6">
                                                  <div className="card patientreat">
                                                    <div className="card-header service-list">
                                                      <h6>Extra Services</h6>
                                                    </div>
                                                    <div className="card-body">
                                                      <div className="table-responsive table-no-card">
                                                        <table className="table-card w-100">
                                                          <thead>
                                                            <tr>
                                                              <th>
                                                                Service Name
                                                              </th>
                                                              <th>Price</th>
                                                              <th>
                                                                Valid From
                                                              </th>
                                                              <th>Valid To</th>
                                                              <th>Action</th>
                                                            </tr>
                                                          </thead>
                                                          <tbody>
                                                            {info?.omca
                                                              ?.extraServices &&
                                                            info.omca.extraServices.filter(
                                                              (item) =>
                                                                item.price,
                                                            ).length > 0 ? (
                                                              info.omca.extraServices.map(
                                                                (
                                                                  item,
                                                                  index,
                                                                ) => {
                                                                  if (
                                                                    !item.price
                                                                  )
                                                                    return null;
                                                                  return (
                                                                    <tr
                                                                      key={
                                                                        item._id ||
                                                                        item.service_type
                                                                      }
                                                                    >
                                                                      <td>
                                                                        {item.serviceName ||
                                                                          "-"}
                                                                      </td>
                                                                      <td>
                                                                        {
                                                                          item.price
                                                                        }
                                                                      </td>
                                                                      <td>
                                                                        {item.startTime
                                                                          ? new Date(
                                                                              item.startTime,
                                                                            ).toLocaleDateString(
                                                                              "en-GB",
                                                                            )
                                                                          : "-"}
                                                                      </td>
                                                                      <td>
                                                                        {item.endTime
                                                                          ? new Date(
                                                                              item.endTime,
                                                                            ).toLocaleDateString(
                                                                              "en-GB",
                                                                            )
                                                                          : "-"}
                                                                      </td>
                                                                      <td>
                                                                        <div className="action-icon">
                                                                          <i
                                                                            className="fa-solid fa-pen-to-square"
                                                                            onClick={() => {
                                                                              hadnlcecEditModal(
                                                                                item,
                                                                                info,
                                                                              );
                                                                            }}
                                                                          ></i>
                                                                          <i
                                                                            className="fa-solid fa-trash"
                                                                            onClick={() => {
                                                                              handledeltePatientserveice(
                                                                                item,
                                                                                info,
                                                                                index,
                                                                              );
                                                                            }}
                                                                          ></i>
                                                                        </div>
                                                                      </td>
                                                                    </tr>
                                                                  );
                                                                },
                                                              )
                                                            ) : (
                                                              <tr>
                                                                <td
                                                                  colSpan="5"
                                                                  style={{
                                                                    textAlign:
                                                                      "center",
                                                                  }}
                                                                >
                                                                  No Data Found
                                                                </td>
                                                              </tr>
                                                            )}
                                                          </tbody>
                                                        </table>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div className="col-md-6">
                                                  <div className="card patientreat">
                                                    <div className="card-header service-list">
                                                      <h6>Free Services</h6>
                                                    </div>
                                                    <div className="card-body">
                                                      <div className="table-responsive table-no-card">
                                                        <table className="table-card w-100">
                                                          <thead>
                                                            <tr>
                                                              <th>
                                                                Service Name
                                                              </th>
                                                              {/* <th>Price</th> */}
                                                              <th>Duration</th>
                                                              {/* <th>Valid To</th>*/}
                                                              <th>Action</th>
                                                            </tr>
                                                          </thead>
                                                          <tbody>
                                                            {info?.omca
                                                              ?.freeServices &&
                                                            info.omca
                                                              .freeServices
                                                              .length > 0 ? (
                                                              info.omca.freeServices.map(
                                                                (
                                                                  item,
                                                                  index,
                                                                ) => {
                                                                  return (
                                                                    <tr
                                                                      key={
                                                                        index
                                                                      }
                                                                    >
                                                                      <td>
                                                                        {item.serviceName ||
                                                                          "-"}
                                                                      </td>

                                                                      <td>
                                                                        {
                                                                          item.duration
                                                                        }
                                                                      </td>

                                                                      <td>
                                                                        <div className="action-icon">
                                                                          {/* <i
                                                                            className="fa-solid fa-pen-to-square"
                                                                            onClick={() => {
                                                                              hadnlcecEditModal(
                                                                                item,
                                                                                info,
                                                                              );
                                                                            }}
                                                                          ></i> */}
                                                                          <i
                                                                            className="fa-solid fa-trash"
                                                                            onClick={() => {
                                                                              handledeltePatientserveice(
                                                                                item,
                                                                                info,
                                                                                index,
                                                                              );
                                                                            }}
                                                                          ></i>
                                                                        </div>
                                                                      </td>
                                                                    </tr>
                                                                  );
                                                                },
                                                              )
                                                            ) : (
                                                              <tr>
                                                                <td
                                                                  colSpan={3}
                                                                  style={{
                                                                    textAlign:
                                                                      "center",
                                                                  }}
                                                                >
                                                                  No Data Found
                                                                </td>
                                                              </tr>
                                                            )}
                                                          </tbody>
                                                        </table>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                {/* <div className="col-md-6">
                                                      <div className="card patientreat">
                                                        <div className="card-header service-list action-icon">
                                                          <h6>Free Services</h6>
                                                        </div>
                                                        <div className="card-body">
                                                          <ul className="free-list">
                                                           {info?.omca?.freeServices?.map(
                                                              (item, index) => (
                                                                <li
                                                                  key={
                                                                    item._id || index
                                                                  }
                                                                >
                                                                  <div className="row">
                                                                    <div className="col-md-12">
                                                                      <div className="para-main-div hosp-info">
                                                                        <p>
                                                                          {" "}
                                                                          {
                                                                            item.serviceName
                                                                          }
                                                                        </p>
                                                                        <div className="action-icon">
                                                                          <i
                                                                            className="fa-solid fa-trash"
                                                                            onClick={() =>
                                                                              EditFreeDelete(
                                                                                item,
                                                                                info,
                                                                                index,
                                                                              )
                                                                            }
                                                                          ></i>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </li>
                                                              ),
                                                            )}
                                                          </ul>
                                                        </div>
                                                      </div>
                                                    </div> */}
                                              </div>
                                            </div>
                                            <div className="card-footer">
                                              <div className="row justify-content-end">
                                                <div className="col-md-12">
                                                  <div className="total-amount">
                                                    <h6 className="mb-0">
                                                      Total Amount:
                                                    </h6>
                                                    <p>
                                                      {info.omca?.totalAmount}
                                                    </p>
                                                  </div>
                                                </div>
                                                <div className="col-md-12">
                                                  <div className="total-amount">
                                                    <h6 className="mb-0">
                                                      Due Amount:
                                                    </h6>
                                                    <p>
                                                      {info.omca?.dueAmount}
                                                    </p>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        {/* for pharmacy data */}
                                        <div className="col-md-12">
                                          <div className="card customstylecard">
                                            <div className="card-header d-flex justify-content-between">
                                              <div>
                                                <h6>Pharmacy</h6>
                                              </div>
                                              <div>
                                                <button
                                                  className="add-button"
                                                  onClick={() => {
                                                    handleclickpharmacycharge(
                                                      info,
                                                    );
                                                  }}
                                                >
                                                  Add Charge
                                                </button>
                                              </div>
                                            </div>
                                            <div className="card-body">
                                              <div className="table-responsive table-no-card">
                                                <table className="table-card w-100">
                                                  <thead>
                                                    <tr>
                                                      <th>Pharmacy Name</th>
                                                      <th>Price</th>
                                                      <th>Date</th>
                                                      <th>Action</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                    {info?.pharmacy
                                                      ?.pharmacyCharges
                                                      ?.length > 0 ? (
                                                      info.pharmacy?.pharmacyCharges?.map(
                                                        (item, index) => (
                                                          <tr key={item._id}>
                                                            <td>
                                                              {item?.service_name ||
                                                                "-"}
                                                            </td>
                                                            <td>
                                                              {item?.price ||
                                                                "-"}
                                                            </td>
                                                            <td>
                                                              {new Date(
                                                                item?.date,
                                                              ).toLocaleDateString(
                                                                "en-GB",
                                                              ) || "-"}
                                                            </td>
                                                            <td>
                                                              <div className="action-icon">
                                                                <i
                                                                  className="fa-solid fa-pen-to-square"
                                                                  onClick={() => {
                                                                    handleeditpharmacycharge(
                                                                      item,
                                                                      info,
                                                                    );
                                                                  }}
                                                                ></i>

                                                                <i
                                                                  className="fa-solid fa-trash text-danger"
                                                                  style={{
                                                                    cursor:
                                                                      "pointer",
                                                                  }}
                                                                  onClick={() =>
                                                                    deletepharmacy(
                                                                      info,
                                                                      index,
                                                                    )
                                                                  }
                                                                ></i>
                                                              </div>
                                                            </td>
                                                          </tr>
                                                        ),
                                                      )
                                                    ) : (
                                                      <tr>
                                                        <td
                                                          colSpan={
                                                            usrFount === "Admin"
                                                              ? 9
                                                              : 7
                                                          }
                                                          style={{
                                                            textAlign: "center",
                                                          }}
                                                        >
                                                          No Data Found
                                                        </td>
                                                      </tr>
                                                    )}
                                                  </tbody>
                                                </table>
                                              </div>
                                            </div>
                                            <div className="card-footer">
                                              <div className="row justify-content-end">
                                                <div className="col-md-12">
                                                  <div className="total-amount">
                                                    <h6 className="mb-0">
                                                      Total Amount:
                                                    </h6>
                                                    <p>
                                                      {
                                                        info?.pharmacy
                                                          ?.totalAmount
                                                      }
                                                    </p>
                                                  </div>
                                                </div>
                                                <div className="col-md-12">
                                                  <div className="total-amount">
                                                    <h6 className="mb-0">
                                                      Due Amount:
                                                    </h6>
                                                    <p>
                                                      {
                                                        info?.pharmacy
                                                          ?.dueAmount
                                                      }
                                                    </p>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </>
                                  ) : (
                                    ""
                                  )}
                                  {activeSubTab === "attendant" &&
                                    selectedTreatmentId && (
                                      <>
                                        <div className="row">
                                          <div className="col-md-12">
                                            <div className="top-collpse">
                                              <div className="treat-buttons mb-0">
                                                <button
                                                  onClick={(e) =>
                                                    handleClickOpen2(
                                                      e,
                                                      selectedTreatmentId,
                                                    )
                                                  }
                                                  className="add-button"
                                                >
                                                  <span>
                                                    <i className="fa fa-plus"></i>
                                                  </span>{" "}
                                                  Add Attendant{" "}
                                                </button>
                                              </div>
                                            </div>
                                            <div className="row gx-3 gy-3">
                                              <div className="col-md-12">
                                                <div className="table-responsive">
                                                  <TableContainer
                                                    component={Paper}
                                                    style={{
                                                      overflowX: "auto",
                                                    }}
                                                  >
                                                    <Table
                                                      stickyHeader
                                                      aria-label="attendant table"
                                                      className="table-no-card"
                                                    >
                                                      <TableHead>
                                                        <TableRow>
                                                          <TableCell>
                                                            Sr.No.
                                                          </TableCell>
                                                          <TableCell>
                                                            Name
                                                          </TableCell>
                                                          <TableCell>
                                                            Relation
                                                          </TableCell>
                                                          <TableCell>
                                                            Contact
                                                          </TableCell>
                                                          <TableCell>
                                                            Country
                                                          </TableCell>
                                                          <TableCell>
                                                            Attendant Address
                                                          </TableCell>
                                                          <TableCell>
                                                            Attendant ID Proof
                                                          </TableCell>
                                                        </TableRow>
                                                      </TableHead>

                                                      <TableBody>
                                                        {attandantFilered.length ===
                                                        0 ? (
                                                          <TableRow>
                                                            <TableCell
                                                              colSpan={7}
                                                              align="center"
                                                            >
                                                              No attendants
                                                              found
                                                            </TableCell>
                                                          </TableRow>
                                                        ) : (
                                                          attandantFilered.map(
                                                            (item, index) => (
                                                              <TableRow
                                                                key={
                                                                  item._id ||
                                                                  index
                                                                }
                                                              >
                                                                <TableCell>
                                                                  {index + 1}
                                                                </TableCell>
                                                                <TableCell>
                                                                  {item?.attendant_fullname ||
                                                                    "N/A"}
                                                                </TableCell>
                                                                <TableCell>
                                                                  {item?.attendant_relation ||
                                                                    "N/A"}
                                                                </TableCell>
                                                                <TableCell>
                                                                  {item?.attendant_contact ||
                                                                    "N/A"}
                                                                </TableCell>
                                                                <TableCell>
                                                                  {item?.country ||
                                                                    "N/A"}
                                                                </TableCell>
                                                                <TableCell>
                                                                  {
                                                                    item?.attendant_address
                                                                  }
                                                                </TableCell>
                                                                <TableCell className="d-flex gap-2">
                                                                  {item
                                                                    ?.attendant_passport
                                                                    ?.length > 0
                                                                    ? item.attendant_passport.map(
                                                                        (
                                                                          file,
                                                                          fIndex,
                                                                        ) => {
                                                                          const filePath =
                                                                            typeof file ===
                                                                            "object"
                                                                              ? file?.path
                                                                              : file;
                                                                          return (
                                                                            <div
                                                                              key={
                                                                                fIndex
                                                                              }
                                                                            >
                                                                              <a
                                                                                href={`https://sisccltd.com/omca_crm/${filePath}`}
                                                                                target="_blank"
                                                                                rel="noopener noreferrer"
                                                                                className="viewbtn"
                                                                              >
                                                                                View{" "}
                                                                                {item
                                                                                  .attendant_passport
                                                                                  .length >
                                                                                1
                                                                                  ? fIndex +
                                                                                    1
                                                                                  : ""}
                                                                              </a>
                                                                            </div>
                                                                          );
                                                                        },
                                                                      )
                                                                    : "Not Uploaded"}
                                                                </TableCell>
                                                              </TableRow>
                                                            ),
                                                          )
                                                        )}
                                                      </TableBody>
                                                    </Table>
                                                  </TableContainer>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </>
                                    )}
                                  {activeSubTab === "payment" &&
                                    selectedTreatmentId && (
                                      <>
                                        <div>
                                          <div className="row">
                                            <div className="col-md-12">
                                              <div className="experience-box">
                                                <div className="top-collpse">
                                                  <div className="treat-buttons">
                                                    <button
                                                      onClick={(e) =>
                                                        handleClickOpen3()
                                                      }
                                                      className="add-button"
                                                    >
                                                      <span>
                                                        <i className="fa fa-plus"></i>
                                                      </span>{" "}
                                                      Add Amount
                                                    </button>
                                                    <button
                                                      onClick={(e) =>
                                                        handleClicexportPayment(
                                                          e,
                                                          info.treatment_id,
                                                        )
                                                      }
                                                      className="add-button"
                                                    >
                                                      <span>
                                                        <i className="fa fa-plus"></i>
                                                      </span>{" "}
                                                      Export
                                                    </button>
                                                  </div>
                                                </div>
                                                <TableContainer
                                                  component={Paper}
                                                >
                                                  <Table className="table-no-card">
                                                    <TableHead>
                                                      <TableRow>
                                                        <TableCell>
                                                          Payment Date
                                                        </TableCell>
                                                        <TableCell>
                                                          Payment Method
                                                        </TableCell>
                                                        <TableCell>
                                                          Payment Amount
                                                        </TableCell>
                                                        <TableCell>
                                                          Paid To
                                                        </TableCell>
                                                        <TableCell>
                                                          Paid For
                                                        </TableCell>
                                                        <TableCell>
                                                          Notes
                                                        </TableCell>

                                                        <TableCell>
                                                          Document
                                                        </TableCell>
                                                        {usrFount ===
                                                        "Admin" ? (
                                                          <>
                                                            <TableCell>
                                                              PDF
                                                            </TableCell>
                                                            <TableCell>
                                                              Action
                                                            </TableCell>
                                                          </>
                                                        ) : (
                                                          ""
                                                        )}
                                                      </TableRow>
                                                    </TableHead>
                                                    <TableBody>
                                                      {paymentsFilered &&
                                                      paymentsFilered.length >
                                                        0 ? (
                                                        paymentsFilered.map(
                                                          (item) => (
                                                            <TableRow
                                                              key={item._id}
                                                            >
                                                              <TableCell>
                                                                {new Date(
                                                                  item?.payment_Date,
                                                                ).toLocaleDateString(
                                                                  "en-GB",
                                                                )}
                                                              </TableCell>
                                                              <TableCell>
                                                                {
                                                                  item?.paymentMethod
                                                                }
                                                              </TableCell>

                                                              <TableCell>
                                                                {
                                                                  item?.paid_amount
                                                                }
                                                              </TableCell>
                                                              <TableCell>
                                                                {item?.paid_to}
                                                              </TableCell>
                                                              <TableCell>
                                                                {item?.paid_for
                                                                  ?.split("_")
                                                                  .map(
                                                                    (word) =>
                                                                      word
                                                                        .charAt(
                                                                          0,
                                                                        )
                                                                        .toUpperCase() +
                                                                      word.slice(
                                                                        1,
                                                                      ),
                                                                  )
                                                                  .join(" ")}
                                                              </TableCell>
                                                              <TableCell>
                                                                {item?.notes}
                                                              </TableCell>

                                                              <TableCell className="action-btn">
                                                                {item?.attachFile ? (
                                                                  <a
                                                                    href={`https://sisccltd.com/omca_crm/${item.attachFile}`}
                                                                    target="_blank"
                                                                    rel="noopener noreferrer"
                                                                  >
                                                                    <i className="fa fa-eye"></i>
                                                                  </a>
                                                                ) : (
                                                                  "-"
                                                                )}
                                                              </TableCell>

                                                              {usrFount ===
                                                              "Admin" ? (
                                                                <>
                                                                  <TableCell>
                                                                    <button
                                                                      className="add-button"
                                                                      onClick={() => {
                                                                        navigate(
                                                                          "/Admin/Patient-Pdfdetails",
                                                                          {
                                                                            state:
                                                                              {
                                                                                data: item?._id,
                                                                              },
                                                                          },
                                                                        );
                                                                      }}
                                                                    >
                                                                      <i className="fa fa-download"></i>
                                                                    </button>
                                                                  </TableCell>
                                                                  <TableCell>
                                                                    <i
                                                                      className="fa-solid fa-trash text-danger"
                                                                      style={{
                                                                        cursor:
                                                                          "pointer",
                                                                      }}
                                                                      onClick={() =>
                                                                        deletePaymentInvoice(
                                                                          item,
                                                                        )
                                                                      }
                                                                    ></i>
                                                                  </TableCell>
                                                                </>
                                                              ) : (
                                                                ""
                                                              )}
                                                            </TableRow>
                                                          ),
                                                        )
                                                      ) : (
                                                        <TableRow>
                                                          <TableCell
                                                            colSpan={
                                                              usrFount ===
                                                              "Admin"
                                                                ? 9
                                                                : 7
                                                            }
                                                            align="center"
                                                          >
                                                            No Data Found
                                                          </TableCell>
                                                        </TableRow>
                                                      )}
                                                    </TableBody>
                                                  </Table>
                                                </TableContainer>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </>
                                    )}
                                  {activeSubTab === "reports" &&
                                    selectedTreatmentId && (
                                      <div>
                                        <div className="row">
                                          <div className="col-md-12">
                                            <div className="top-collpse">
                                              <div className="treat-buttons">
                                                <button
                                                  className="add-button"
                                                  onClick={(e) =>
                                                    handleClickOpen10(
                                                      e,
                                                      selectedTreatmentId,
                                                    )
                                                  }
                                                >
                                                  <span>
                                                    <i className="fa fa-plus"></i>
                                                  </span>
                                                  Add Report
                                                </button>
                                              </div>
                                            </div>

                                            <div className="table-responsive">
                                              <TableContainer component={Paper}>
                                                <Table className="table-no-card">
                                                  <TableHead>
                                                    <TableRow>
                                                      <TableCell>
                                                        Treatment ID
                                                      </TableCell>
                                                      <TableCell>
                                                        Report Title
                                                      </TableCell>
                                                      <TableCell>
                                                        Report Date
                                                      </TableCell>
                                                      <TableCell>
                                                        Added By
                                                      </TableCell>

                                                      {usrFount === "Admin" ? (
                                                        <>
                                                          {" "}
                                                          <TableCell>
                                                            Reports
                                                          </TableCell>
                                                          <TableCell>
                                                            Action
                                                          </TableCell>
                                                        </>
                                                      ) : (
                                                        ""
                                                      )}
                                                    </TableRow>
                                                  </TableHead>

                                                  <TableBody>
                                                    {reportsFilered1 &&
                                                    reportsFilered1.length >
                                                      0 ? (
                                                      reportsFilered1.map(
                                                        (item) => (
                                                          <TableRow
                                                            key={item._id}
                                                          >
                                                            <TableCell>
                                                              {
                                                                item?.treatmentId
                                                              }
                                                            </TableCell>

                                                            <TableCell>
                                                              {
                                                                item?.reportTitle
                                                              }
                                                            </TableCell>

                                                            <TableCell>
                                                              {new Date(
                                                                item?.treatment_report_date,
                                                              ).toLocaleDateString(
                                                                "en-GB",
                                                              )}
                                                            </TableCell>
                                                            <TableCell>
                                                              {item?.platform ===
                                                              1
                                                                ? "CRM"
                                                                : "Hospital"}
                                                            </TableCell>

                                                            {usrFount ===
                                                            "Admin" ? (
                                                              <>
                                                                {" "}
                                                                <TableCell>
                                                                  <a
                                                                    href={`${image}${item.treatmentReport}`}
                                                                    target="_blank"
                                                                    rel="noreferrer"
                                                                  >
                                                                    Download
                                                                    Report
                                                                  </a>
                                                                </TableCell>
                                                                <TableCell>
                                                                  <i
                                                                    className="fa-solid fa-trash text-danger"
                                                                    style={{
                                                                      cursor:
                                                                        "pointer",
                                                                    }}
                                                                    onClick={() =>
                                                                      handledeleteReport(
                                                                        item,
                                                                      )
                                                                    }
                                                                  ></i>
                                                                </TableCell>
                                                              </>
                                                            ) : (
                                                              ""
                                                            )}
                                                          </TableRow>
                                                        ),
                                                      )
                                                    ) : (
                                                      <TableRow>
                                                        <TableCell
                                                          colSpan={
                                                            usrFount === "Admin"
                                                              ? 6
                                                              : 4
                                                          }
                                                          align="center"
                                                        >
                                                          No Data Found
                                                        </TableCell>
                                                      </TableRow>
                                                    )}
                                                  </TableBody>
                                                </Table>
                                              </TableContainer>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                  {activeSubTab === "appointment" &&
                                    selectedTreatmentId ===
                                      info.treatment_id && (
                                      <div className="row">
                                        <div className="col-md-12">
                                          <div className="top-collpse">
                                            <div className="treat-buttons mb-0">
                                              <button
                                                className="add-button"
                                                onClick={(e) =>
                                                  handleClickOpen1(
                                                    e,
                                                    selectedTreatmentId,
                                                    info,
                                                  )
                                                }
                                              >
                                                <span>
                                                  <i className="fa fa-plus"></i>
                                                </span>
                                                Add Appointment
                                              </button>
                                            </div>
                                          </div>
                                          <div className="table-responsive table-no-card">
                                            <table className="table-card w-100">
                                              <thead>
                                                <tr>
                                                  <th>ID</th>
                                                  <th>Vehicle No</th>
                                                  <th>Driver Name</th>
                                                  <th>Driver Contact</th>
                                                  <th>Pickup Time</th>
                                                  <th>Date</th>
                                                  <th>Notes</th>
                                                  <th>Status</th>
                                                  <th>Action</th>
                                                </tr>
                                              </thead>
                                              <tbody>
                                                {appointmentTabel.length ===
                                                0 ? (
                                                  <tr>
                                                    <td
                                                      colSpan="8"
                                                      className="text-center"
                                                    >
                                                      No Appointment Found
                                                    </td>
                                                  </tr>
                                                ) : (
                                                  appointmentTabel.map(
                                                    (item) => (
                                                      <tr key={item._id}>
                                                        <td>
                                                          {item.appointmentId}
                                                        </td>
                                                        <td>
                                                          {item.mode !==
                                                          "online"
                                                            ? item.vehicle_no
                                                            : "-"}
                                                        </td>
                                                        <td>
                                                          {item.mode !==
                                                          "online"
                                                            ? item.driver_name
                                                            : "-"}
                                                        </td>
                                                        <td>
                                                          {item.mode !==
                                                          "online"
                                                            ? item.driver_contact
                                                            : "-"}
                                                        </td>
                                                        <td>
                                                          {item.mode !==
                                                          "online"
                                                            ? item.pickup_time
                                                            : "-"}
                                                        </td>
                                                        <td>
                                                          {item.appointment_Date
                                                            ? new Date(
                                                                item.appointment_Date,
                                                              )
                                                                .toISOString()
                                                                .slice(0, 10)
                                                            : ""}
                                                        </td>
                                                        <td>{item.note}</td>
                                                        <td>
                                                          <span className="badge bg-primary">
                                                            {item.status}
                                                          </span>
                                                        </td>
                                                        <td>
                                                          <td>
                                                            <div className="action-icon">
                                                              <i
                                                                className="fa-solid fa-pen-to-square"
                                                                onClick={() =>
                                                                  handleclickeditfunc(
                                                                    item,
                                                                    info,
                                                                  )
                                                                }
                                                              ></i>
                                                              <i
                                                                className="fa-solid fa-trash"
                                                                onClick={() =>
                                                                  handleclickeditdelete(
                                                                    item,
                                                                    info,
                                                                  )
                                                                }
                                                              ></i>
                                                            </div>
                                                          </td>
                                                        </td>
                                                      </tr>
                                                    ),
                                                  )
                                                )}
                                              </tbody>
                                            </table>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                  {activeSubTab === "notes" &&
                                    selectedTreatmentId ===
                                      info.treatment_id && (
                                      <div className="col-md-12">
                                        <div className="card patientreat">
                                          <div className="card-header service-list d-flex justify-content-between">
                                            <div>
                                              <h6>Notes</h6>
                                            </div>
                                            <div>
                                              <div>
                                                <button
                                                  className="add-button"
                                                  onClick={(e) =>
                                                    handleClickOpenNotes(
                                                      e,
                                                      selectedTreatmentId,
                                                      info,
                                                    )
                                                  }
                                                >
                                                  <span>
                                                    <i className="fa fa-plus text-white"></i>
                                                  </span>
                                                  Add Notes
                                                </button>
                                              </div>
                                            </div>
                                          </div>
                                          <div className="card-body">
                                            <div className="table-responsive table-no-card">
                                              <table className="table-card w-100">
                                                <thead>
                                                  <tr>
                                                    <th>Note</th>
                                                    <th>Date</th>
                                                    <th>Added By</th>
                                                    <th>Images</th>
                                                    <th>Action</th>
                                                  </tr>
                                                </thead>
                                                <tbody>
                                                  {notesTable &&
                                                  notesTable.length > 0 ? (
                                                    notesTable.map(
                                                      (item, index) => {
                                                        return (
                                                          <tr
                                                            key={
                                                              item._id || index
                                                            }
                                                          >
                                                            <td>
                                                              {item.note || "-"}
                                                            </td>
                                                            <td>
                                                              {item?.date
                                                                ? new Date(
                                                                    item.date,
                                                                  ).toLocaleDateString(
                                                                    "en-GB",
                                                                  )
                                                                : "-"}
                                                            </td>
                                                            <td>
                                                              {item.platform ==
                                                              "1"
                                                                ? "CRM"
                                                                : "Hospital"}{" "}
                                                            </td>
                                                            <td>
                                                              {item
                                                                ?.treatmentNoteImages
                                                                ?.length > 0
                                                                ? item.treatmentNoteImages.map(
                                                                    (
                                                                      img,
                                                                      index,
                                                                    ) => (
                                                                      <button
                                                                        key={
                                                                          index
                                                                        }
                                                                        className="btn btn-sm btn-primary me-1"
                                                                        onClick={() =>
                                                                          window.open(
                                                                            `https://sisccltd.com/omca_crm/${img}`,
                                                                            "_blank",
                                                                          )
                                                                        }
                                                                      >
                                                                        View
                                                                      </button>
                                                                    ),
                                                                  )
                                                                : "-"}
                                                            </td>

                                                            <td>
                                                              <div className="action-icon">
                                                                <i
                                                                  className="fa-solid fa-pen-to-square"
                                                                  onClick={() =>
                                                                    EditButton(
                                                                      item,
                                                                      info,
                                                                    )
                                                                  }
                                                                ></i>
                                                                <i
                                                                  className="fa-solid fa-trash"
                                                                  onClick={() =>
                                                                    EditDelete(
                                                                      item,
                                                                      info,
                                                                    )
                                                                  }
                                                                ></i>
                                                              </div>
                                                            </td>
                                                          </tr>
                                                        );
                                                      },
                                                    )
                                                  ) : (
                                                    <tr>
                                                      <td
                                                        colSpan="5"
                                                        style={{
                                                          textAlign: "center",
                                                        }}
                                                      >
                                                        No Data Found
                                                      </td>
                                                    </tr>
                                                  )}
                                                </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                </div>
                              </div>
                            );
                          })}
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <React.Fragment>
        <Dialog
          fullWidth
          maxWidth="sm"
          open={treatmentPlanPopup}
          onClose={PlanTreatmentPopupClose}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Plan Treatment</h6>
            </div>
            <div className="cross-icon" onClick={PlanTreatmentPopupClose}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box view-table-detail">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 3,
                width: "100%",
              }}
              className="contact-form"
            >
              <Box>
                <Box>
                  <div className="field-set">
                    <label>
                      Treatment course<span className="text-danger">*</span>
                    </label>
                    <Autocomplete
                      options={Treatment || []}
                      getOptionLabel={(option) => option.name || ""}
                      onChange={(e, newValue) => {
                        setFieldValue(newValue);
                        handleChangeDetails123(newValue);
                        setErrors((prev) => ({ ...prev, treatment: "" }));
                      }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder="Select Treatment Course"
                          error={!!errors.treatment}
                          helperText={errors.treatment}
                        />
                      )}
                    />
                  </div>
                </Box>
                <Box>
                  <div className="field-set">
                    <label>
                      Select Hospital<span className="text-danger">*</span>
                    </label>
                    <Autocomplete
                      multiple
                      options={hospitlID || []}
                      value={hospitalId || []}
                      disableCloseOnSelect
                      getOptionLabel={(option) => option.name}
                      onChange={(e, values) => {
                        const isSelectAll = values.find(
                          (val) => val._id === "all",
                        );

                        if (isSelectAll) {
                          const allHospitals = hospitlID.filter(
                            (item) => item._id !== "all",
                          );
                          setHospitalId(allHospitals);
                        } else {
                          setHospitalId(values);
                        }

                        setErrors((prev) => ({ ...prev, hospitals: "" }));
                      }}
                      renderOption={(props, option, { selected }) => (
                        <li {...props}>
                          <Checkbox
                            checked={
                              option._id === "all"
                                ? hospitalId.length === hospitlID.length - 1
                                : selected
                            }
                          />
                          {option.name}
                        </li>
                      )}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder="Hospital"
                          error={!!errors.hospitals}
                        />
                      )}
                    />
                  </div>
                  {errors.hospitals && (
                    <small className="text-danger">{errors.hospitals}</small>
                  )}
                </Box>
                <Box>
                  <div className="field-set">
                    <label>
                      Select Reports<span className="text-danger"></span>
                    </label>
                    <input
                      type="file"
                      multiple
                      className="form-control"
                      onChange={(e) => {
                        setImages(Array.from(e.target.files));
                        setErrors((prev) => ({ ...prev, reports: "" }));
                      }}
                    />
                  </div>
                  {errors.reports && (
                    <small className="text-danger">{errors.reports}</small>
                  )}
                </Box>
                <Box>
                  <div className="field-set mb-0">
                    <label>
                      Notes<span className="text-danger"></span>
                    </label>
                    <input
                      className="form-control"
                      onChange={(e) => {
                        setValue1(e.target.value);
                      }}
                    />
                  </div>
                </Box>
              </Box>
              <DialogActions className="submit-main">
                <Button
                  type="button"
                  onClick={uploadmultipleRecord}
                  variant="contained"
                >
                  Send
                </Button>
              </DialogActions>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth
          maxWidth="sm"
          open={modalEditServiceOpen}
          onClose={hadnlcecEcloseeModal}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Edit Service</h6>
            </div>
            <div className="cross-icon" onClick={hadnlcecEcloseeModal}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 3,
                width: "100%",
              }}
              className="contact-form"
            >
              <Box sx={{ display: "flex", gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <label>
                      Service<span className="text-danger"></span>
                    </label>
                    <input
                      className="form-control"
                      onChange={editServiceandlechange}
                      value={data.serviceName}
                      disabled
                      name="serviceId"
                    />
                  </div>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <label>
                      Enter Price<span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      value={data.price}
                      name="price"
                      onChange={editServiceandlechange}
                      placeholder="Enter price"
                    />
                  </div>
                </Box>
              </Box>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <div className="field-set mb-0">
                      <label>
                        Start Date<span className="text-danger">*</span>
                      </label>
                      <input
                        type="date"
                        className="form-control"
                        name="startTime"
                        value={
                          data.startTime ? data.startTime.split("T")[0] : ""
                        }
                        onChange={editServiceandlechange}
                        placeholder="Enter price"
                      />
                    </div>
                  </div>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <label>
                      End Date<span className="text-danger">*</span>
                    </label>
                    <input
                      type="date"
                      className="form-control"
                      name="endTime"
                      value={data.endTime ? data.endTime.split("T")[0] : ""}
                      onChange={editServiceandlechange}
                      placeholder="Enter price"
                    />
                  </div>
                </Box>
              </Box>

              <DialogActions className="submit-main">
                <Button
                  type="button"
                  onClick={handlesubmitdataserviceEdit}
                  variant="contained"
                >
                  Submit
                </Button>
              </DialogActions>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog fullWidth maxWidth="sm" open={openModal} onClose={closeModal}>
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Add Service</h6>
            </div>
            <div className="cross-icon" onClick={closeModal}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 3,
                width: "100%",
              }}
              className="contact-form"
            >
              <Box sx={{ display: "flex", gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <label>
                      Select Service<span className="text-danger">*</span>
                    </label>
                    <select
                      className="form-control"
                      onChange={andlechange}
                      name="serviceId"
                    >
                      <option>Select</option>
                      {undadedservice?.map((item, index) => (
                        <option key={index} value={item.serviceId}>
                          {item.serviceName}
                        </option>
                      ))}
                    </select>
                  </div>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <label>
                      Enter Price<span className="text-danger">*</span>
                    </label>
                    <input
                      type="number"
                      className="form-control"
                      value={data.price}
                      name="price"
                      onChange={andlechange}
                      placeholder="Enter price"
                    />
                  </div>
                </Box>
              </Box>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <div className="field-set mb-0">
                      <label>
                        Start Date<span className="text-danger">*</span>
                      </label>
                      <input
                        type="date"
                        className="form-control"
                        name="start_date"
                        onChange={andlechangedate}
                        placeholder="Enter price"
                      />
                    </div>
                  </div>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <div className="field-set mb-0">
                    <label>
                      End Date<span className="text-danger">*</span>
                    </label>
                    <input
                      type="date"
                      className="form-control"
                      name="end_date"
                      onChange={andlechangedate}
                      placeholder="Enter price"
                    />
                  </div>
                </Box>
              </Box>

              <DialogActions className="submit-main">
                <Button
                  type="button"
                  onClick={handlesubmitdata}
                  variant="contained"
                >
                  Submit
                </Button>
              </DialogActions>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={open}
          onClose={handleClose}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Add Hospital</h6>
            </div>
            <div className="cross-icon" onClick={handleClose}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
                minHeight: "350px",
              }}
              className="contact-form"
            >
              <Box>
                <form
                  id="contact-form"
                  className="contact-form"
                  method="post"
                  role="form"
                >
                  <div className="field-set">
                    <label>
                      Hospital Name<span className="text-danger">*</span>
                    </label>
                    <Autocomplete
                      disablePortal
                      options={dataHospital?.map((job) => job.name) || []} // Fallback to empty array
                      onChange={(e, value) => {
                        const selectedCourse = dataHospital?.find(
                          (job) => job.name === value,
                        );
                        const courseId = selectedCourse;
                        setHospitalId(courseId);
                      }}
                      renderInput={(params) => (
                        <TextField {...params} placeholder="Hospital" />
                      )}
                      size="small"
                      style={{
                        backgroundColor:
                          "linear-gradient(181deg, #22c7b8 0%, #0ba6df 72%)",
                        border: "0 !important",
                        borderColor: "transparent",
                      }}
                    />
                  </div>
                  <div className="field-set">
                    <label>
                      Treatment Id<span className="text-danger">*</span>
                    </label>
                    <input
                      type="email"
                      placeholder="Treatment ID"
                      className="form-control"
                      name="treatmentId"
                      required=""
                      value={treatmentId}
                    />
                  </div>

                  <DialogActions className="submit-main">
                    <Button
                      type="submit"
                      onClick={(e) => handlesubmit(e)}
                      variant="contained"
                      disabled={isSubmitting} //✅ disables button while submitting
                    >
                      {isSubmitting ? "Submitting..." : "Submit"}
                    </Button>
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={open1}
          onClose={handleClose1}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>{edited === true ? "Edit" : "Add"} Appointment</h6>
            </div>
            <div className="cross-icon" onClick={handleClose1}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box view-table-detail">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <form
                  id="contact-form"
                  className="contact-form"
                  method="post"
                  role="form"
                >
                  <div className="field-set">
                    <div>
                      <h6>Appointment will be:</h6>
                      <div className="d-flex gap-3">
                        <div className="radio-on">
                          <label>
                            <input
                              type="radio"
                              name="status"
                              value="online"
                              checked={statuddropdown === "online"}
                              onChange={(e) =>
                                setStatuddropdown(e.target.value)
                              }
                            />
                            Online
                          </label>
                        </div>
                        <div className="radio-on">
                          <label>
                            <input
                              type="radio"
                              name="status"
                              value="offline"
                              checked={statuddropdown === "offline"}
                              onChange={(e) =>
                                setStatuddropdown(e.target.value)
                              }
                            />
                            Offline
                          </label>
                        </div>
                      </div>
                    </div>
                    <label>
                      {" "}
                      Hospital<span className="text-danger">*</span>
                    </label>
                    {/* <Autocomplete
                      disablePortal
                      options={ishospitalArray || []}
                      getOptionLabel={(option) => option.hospital_Name || ""}
                      value={appHospital}
                      onChange={(e, value) => {
                        setAppHospital(value);
                      }}
                      isOptionEqualToValue={(option, value) =>
                        option?.hospital_id === value?.hospital_id
                      }
                      renderInput={(params) => <TextField {...params} />}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          padding: "0px",
                          "&:hover fieldset": {
                            borderColor: "#ced4da",
                          },
                        },
                      }}
                    /> */}
                    <TextField
                      fullWidth
                      value={hospitalData.hospital_Name || ""}
                      onChange={(e) => {
                        const value = e.target.value;

                        const matchedHospital = ishospitalArray.find(
                          (item) => item.hospital_Name === value,
                        );

                        setHospitalData({
                          hospital_Name: value,
                          hospital_id: matchedHospital
                            ? matchedHospital.hospital_id
                            : "",
                        });
                      }}
                    />
                  </div>
                  <div className="field-set">
                    <label>
                      Notes<span className="text-danger">*</span>
                    </label>
                    <textarea
                      id="w3review"
                      name="discussionNotes"
                      rows="4"
                      cols="50"
                      className="form-control"
                      component="textarea"
                      placeholder="Note"
                      onChange={(e) => setNote(e.target.value)}
                      value={note}
                    />
                    <span style={{ color: "red" }}>
                      {appointErr && !note ? "*Please Enter Your  note" : ""}
                    </span>
                  </div>
                  <div className="field-set">
                    <label>
                      Appointment Date<span className="text-danger">*</span>
                    </label>
                    <input
                      type="date"
                      id="birthday"
                      name="date"
                      placeholder="Appointment Date"
                      className="form-control"
                      onChange={(e) => setDate(e.target.value)}
                      value={
                        date ? new Date(date).toISOString().split("T")[0] : ""
                      }
                      min={new Date().toISOString().split("T")[0]}
                    />

                    <span style={{ color: "red" }}>
                      {appointErr && !date ? "*Please Enter Your date" : ""}
                    </span>
                  </div>
                  {statuddropdown === "offline" ? (
                    <>
                      <div className="field-set">
                        <label>
                          Pickup Time<span className="text-danger">*</span>
                        </label>
                        <input
                          type="time"
                          id="birthday"
                          name="pickup_time"
                          placeholder="pickup_time"
                          className="form-control"
                          onChange={(e) => setPickuptime(e.target.value)}
                          value={pickuptime}
                        />
                        <span style={{ color: "red" }}>
                          {appointErr && !pickuptime
                            ? "*Please Select Pickup Time"
                            : ""}
                        </span>
                      </div>
                      <div className="field-set">
                        <label>
                          Driver Name<span className="text-danger">*</span>
                        </label>
                        <input
                          type="text"
                          id="birthday"
                          name="driver_name"
                          placeholder="Driver Name"
                          className="form-control"
                          onChange={(e) => setDrivername(e.target.value)}
                          value={drivername}
                        />
                        <span style={{ color: "red" }}>
                          {appointErr && !drivername
                            ? "*Please Enter the Driver Name"
                            : ""}
                        </span>
                      </div>
                      <div className="field-set">
                        <label>
                          Driver Contact<span className="text-danger"></span>
                        </label>
                        <input
                          type="number"
                          id="birthday"
                          name="driver_contact"
                          placeholder="Driver Contact"
                          className="form-control"
                          onChange={(e) => setDrivercontact(e.target.value)}
                          value={drivercontact}
                        />
                      </div>
                      <div className="field-set">
                        <label>
                          Vehicle Number<span className="text-danger"></span>
                        </label>
                        <input
                          type="type"
                          id="birthday"
                          name="vehicle_no"
                          placeholder="Vehicle Number"
                          className="form-control"
                          onChange={(e) => setVehicalnumber(e.target.value)}
                          value={vehicalnumber}
                        />
                      </div>
                    </>
                  ) : (
                    ""
                  )}
                  <DialogActions className="submit-main">
                    {!edited && (
                      <Button
                        type="submit"
                        variant="contained"
                        onClick={(e) =>
                          statuddropdown === "offline"
                            ? handlesubmitAppoint(e)
                            : handlesubmitAppoint111(e)
                        }
                      >
                        Submit
                      </Button>
                    )}

                    {edited && (
                      <Button
                        type="button" // 🔥 IMPORTANT
                        variant="contained"
                        color="primary"
                        onClick={handleExtraButton}
                      >
                        Edit Appointment
                      </Button>
                    )}
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={open2}
          onClose={handleClose2}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Add Attendant Details</h6>
            </div>
            <div className="cross-icon" onClick={handleClose2}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <form id="contact-form" className="contact-form">
                  <div className="row">
                    <div className="col-6">
                      <div className="field-set">
                        <label>
                          Name<span className="text-danger">*</span>
                        </label>
                        <div className="upload-input">
                          <input
                            type="text"
                            name="attendant_fullname"
                            className="form-control"
                            value={filesData.attendant_fullname}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="field-set">
                        <label>
                          Attendant Relation
                          <span className="text-danger">*</span>
                        </label>
                        <div className="upload-input">
                          <input
                            type="text"
                            name="attendant_relation"
                            className="form-control"
                            value={filesData.attendant_relation}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-6">
                      <div className="field-set">
                        <label>
                          Country<span className="text-danger">*</span>
                        </label>

                        <Autocomplete
                          options={Countries || []}
                          getOptionLabel={(option) => option?.name || ""}
                          value={
                            Countries?.find(
                              (country) => country.name === filesData.country,
                            ) || null
                          }
                          onChange={(event, newValue) => {
                            setFilesData({
                              ...filesData,
                              country: newValue?.name || "",
                              dial_code: newValue?.dial_code || "",
                            });
                          }}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              placeholder="Select Country"
                              size="small"
                            />
                          )}
                        />
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="field-set">
                        <label>
                          Attendant Contact
                          <span className="text-danger">*</span>
                        </label>

                        <div className="country-code">
                          <input
                            type="text"
                            className="form-control code-dial"
                            value={filesData.dial_code}
                            disabled
                          />

                          <input
                            type="text"
                            name="attendant_contact"
                            className="form-control code-in"
                            value={filesData.attendant_contact}
                            onKeyPress={handkekeypreees}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-6">
                      <div className="field-set">
                        <label>
                          Attendant Id Proof
                          <span className="text-danger">*</span>
                        </label>
                        <div className="upload-input">
                          <input
                            type="file"
                            multiple
                            accept="image/*,application/pdf"
                            className="form-control"
                            onChange={(e) =>
                              handleFileChange(e, "Attende_passport")
                            }
                          />
                        </div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="field-set">
                        <label>
                          Attendant Address
                          <span className="text-danger">*</span>
                        </label>
                        <div className="upload-input">
                          <input
                            type="text"
                            name="attendant_address"
                            className="form-control"
                            value={filesData.attendant_address}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <DialogActions className="submit-main">
                    <Button
                      type="submit"
                      onClick={handleKysDetail}
                      variant="contained"
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={dataImperial}
          onClose={dataIwemperial}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Edit Hospital Charge</h6>
            </div>
            <div className="cross-icon" onClick={dataIwemperial}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <form id="contact-form" className="contact-form">
                  <div className="field-set">
                    <label>
                      Enter Charge<span className="text-danger">*</span>
                    </label>
                    <input
                      id="w3review"
                      name="setNoteHospital2"
                      className="form-control"
                      placeholder="Charge"
                      onKeyPress={(e) => {
                        handkekeypreees(e);
                      }}
                      onChange={(e) => setNoteHospital2(e.target.value)}
                      value={noteHospital2}
                    />
                  </div>
                  <DialogActions className="submit-main">
                    <Button
                      variant="contained"
                      onClick={() => {
                        handleNothospitalchargeesdata();
                      }}
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
        <ToastContainer />
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={open5}
          onClose={handleClose5}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Add Notes</h6>
            </div>
            <div className="cross-icon" onClick={handleClose5}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <form id="contact-form" className="contact-form">
                  <div className="field-set">
                    <label>
                      Notes<span className="text-danger">*</span>
                    </label>
                    <textarea
                      id="w3review"
                      name="discussionNotes"
                      rows="4"
                      cols="50"
                      className="form-control"
                      placeholder="Note"
                      onChange={(e) => setNote2(e.target.value)}
                      value={note2}
                    />
                    <span style={{ color: "red" }}>
                      {noteErr && !note2 ? "Please Enter Your  note" : ""}
                    </span>
                  </div>
                  <div className="field-set">
                    <label>Upload Images</label>
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      className="form-control"
                      onChange={(e) => setImages([...e.target.files])}
                    />
                  </div>
                  <div className="field-set">
                    <label>
                      Date<span className="text-danger">*</span>
                    </label>
                    <input
                      type="date"
                      id="birthday"
                      name="date"
                      placeholder="Date"
                      className="form-control"
                      onChange={(e) => setDate2(e.target.value)}
                      value={date2}
                      min={new Date().toISOString().split("T")[0]}
                    />
                    <span style={{ color: "red" }}>
                      {noteErr && !date2 ? "Please Enter Your  date" : ""}
                    </span>
                  </div>
                  <DialogActions className="submit-main">
                    <Button
                      type="submit"
                      variant="contained"
                      onClick={handleNotesdata}
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
        <ToastContainer />
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={editModalNotes}
          onClose={handleCloseEditModal}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Edit Notes</h6>
            </div>
            <div className="cross-icon" onClick={handleCloseEditModal}>
              <i className="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              component="form"
              className="contact-form"
              onSubmit={(e) => {
                e.preventDefault();
                editNotes();
              }}
            >
              <div className="field-set">
                <label>
                  Notes<span className="text-danger">*</span>
                </label>
                <textarea
                  className="form-control"
                  rows="4"
                  placeholder="Note"
                  onChange={(e) => setNote2(e.target.value)}
                  value={note2}
                />
                <span style={{ color: "red" }}>
                  {noteErr && !note2 ? "Please Enter Your note" : ""}
                </span>
              </div>
              <div className="field-set">
                <label>Upload Images</label>

                <input
                  type="file"
                  multiple
                  accept="image/*"
                  className="form-control"
                  onChange={(e) => setImages([...e.target.files])}
                />
              </div>
              <div className="field-set">
                <label>
                  Date<span className="text-danger">*</span>
                </label>
                <input
                  type="date"
                  className="form-control"
                  onChange={(e) => setDate2(e.target.value)}
                  value={date2}
                  min={date2 || new Date().toISOString().split("T")[0]}
                />
                <span style={{ color: "red" }}>
                  {noteErr && !date2 ? "Please Enter Your date" : ""}
                </span>
              </div>
              <DialogActions className="submit-main">
                <Button type="submit" variant="contained">
                  Submit
                </Button>
              </DialogActions>
            </Box>
          </DialogContent>
        </Dialog>
        <ToastContainer />
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={open32}
          onClose={handleclosePerforma}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Add Invoice</h6>
            </div>
            <div className="cross-icon" onClick={handleclosePerforma}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <form id="contact-form" className="contact-form">
                  <div className="field-set">
                    <label>
                      Add Performa Invoice<span className="text-danger"></span>
                    </label>
                    <input
                      type="file"
                      id="birthday"
                      name="perfomainvoice"
                      placeholder="Appointment Date"
                      className="form-control"
                      accept=".pdf,image/*"
                      onChange={AddpaymentOnchnage123}
                    />
                  </div>
                  <DialogActions className="submit-main">
                    <Button
                      // type="submit"
                      onClick={() => {
                        handleAddTritmentPaymenttestsubmit();
                      }}
                      variant="contained"
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={open3}
          onClose={handleClose3}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Add Amount</h6>
            </div>
            <div className="cross-icon" onClick={handleClose3}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <form
                  id="contact-form"
                  className="contact-form view-table-detail"
                >
                  <div className="field-set">
                    <label>
                      Paid To <span className="text-danger">*</span>
                    </label>
                    <select
                      placeholder="payment Method"
                      className="form-control"
                      name="paid_to"
                      required
                      onChange={handlefilechange}
                    >
                      <option>Select</option>
                      <option value="OMCA">OMCA</option>
                      <option value="Hospital">Hospital</option>
                      <option value="Pharmacy">Pharmacy</option>
                    </select>
                  </div>
                  <div className="field-set">
                    <label>
                      Paid For <span className="text-danger">*</span>
                    </label>
                    <select
                      placeholder="payment Method"
                      className="form-control"
                      name="paid_for"
                      required
                      onChange={handlefilechange}
                    >
                      <option>Select</option>
                      <option value="treatment">Treatment</option>
                      <option value="service">Service</option>
                      <option value="guest_house">Guest House</option>
                      <option value="pharmacy">Pharmacy</option>
                      <option value="hospital_charges">Hospital Charges</option>
                    </select>
                  </div>
                  <div className="field-set">
                    <label>
                      Attach Invoice <span className="text-danger">*</span>
                    </label>
                    <input
                      type="file"
                      className="form-control"
                      name="attachFile"
                      onChange={handleAttachFile}
                    />
                  </div>

                  <div className="field-set">
                    <label>
                      Paid Amount<span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="paid amount"
                      className="form-control"
                      onKeyPress={handleKeyPress}
                      name="paid_amount"
                      required=""
                      onChange={AddpaymentOnchnage}
                      value={data.paid_amount}
                    />
                  </div>
                  {/* <div>{info.treatment_due_payment}</div> */}
                  <div className="field-set">
                    <label>
                      Payment Method<span className="text-danger"></span>
                    </label>
                    <select
                      placeholder="payment Method"
                      className="form-control"
                      name="paymentMethod"
                      required=""
                      onChange={AddpaymentOnchnage}
                      value={data.paymentMethod}
                    >
                      <option>Select</option>
                      <option value="Cash">Cash</option>
                      <option value="UPI">Online via UPI</option>
                      <option value="Via Net Banking">Via Net Banking</option>
                      <option value="Credit/Debit Card">
                        Debit Card / Credit Card
                      </option>
                    </select>
                  </div>
                  <div className="field-set">
                    <label>
                      Payment Date<span className="text-danger"></span>
                    </label>
                    <input
                      type="date"
                      id="birthday"
                      name="payment_Date"
                      placeholder="Appointment Date"
                      className="form-control"
                      onChange={AddpaymentOnchnage}
                      value={data.payment_Date}
                      max={new Date().toISOString().split("T")[0]} // Prevent future date
                    />
                  </div>
                  <div className="field-set">
                    <label>
                      Notes<span className="text-danger"></span>
                    </label>
                    <input
                      type="text"
                      placeholder="notes"
                      className="form-control"
                      name="notes"
                      required=""
                      onChange={AddpaymentOnchnage}
                      value={data.notes}
                    />
                  </div>
                  <DialogActions className="submit-main">
                    <Button
                      // type="submit"
                      onClick={() => {
                        handleAddTritmentPayment();
                      }}
                      // onClick={(e) => handleAddTritmentPayment(e)}
                      variant="contained"
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={open10}
          onClose={handleClose10}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Add Reports</h6>
            </div>
            <div className="cross-icon" onClick={handleClose10}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box view-table-detail">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <div id="contact-form" className="contact-form">
                  <div className="field-set">
                    <label>
                      Reports Title<span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="Report Title"
                      className="form-control"
                      multiple
                      name="reportTitle"
                      onChange={handlefilechange}
                    />
                  </div>
                  <div className="field-set">
                    <label>
                      Reports <span className="text-danger">*</span>
                    </label>
                    <input
                      type="file"
                      multiple
                      className="form-control"
                      name="treatmentReport"
                      onChange={handleFileChange1}
                    />
                  </div>
                  <div className="field-set">
                    <label>
                      Treatment Report Date{" "}
                      <span className="text-danger">*</span>
                    </label>
                    <input
                      type="date"
                      placeholder="payment Method"
                      className="form-control"
                      name="treatment_report_date"
                      required
                      onChange={handlefilechange}
                    />
                  </div>

                  <DialogActions className="submit-main">
                    <Button
                      // type="submit"
                      onClick={handleClickSubmit}
                      variant="contained"
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </div>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={editPatientProfile}
          onClose={EditButtoneditprofileClose}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Upload Profile</h6>
            </div>
            <div className="cross-icon" onClick={EditButtoneditprofileClose}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <div id="contact-form" className="contact-form">
                  <div className="field-set">
                    <label>
                      Profile <span className="text-danger">*</span>
                    </label>
                    <input
                      type="file"
                      placeholder="payment Method"
                      className="form-control"
                      name="patient_Profile"
                      accept="image/*"
                      required
                      onChange={handleFileChange12}
                    />
                  </div>

                  <DialogActions className="submit-main">
                    <Button
                      // type="submit"
                      onClick={() => handleupdateProfile()}
                      variant="contained"
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </div>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={openmodalCharge}
          onClose={handleclickclosecharge}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>{isEditT === true ? "Edit" : "Add"} Hospital Charge</h6>
            </div>
            <div className="cross-icon" onClick={handleclickclosecharge}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <div className="field-set">
                  <label>
                    Service Name<span className="text-danger"></span>
                  </label>
                  <div className="upload-input">
                    <input
                      type="text"
                      className="form-control"
                      name="service_name"
                      value={hospitalCharge.service_name}
                      onChange={addhospitalChare}
                    />
                  </div>
                </div>
                <div className="field-set">
                  <label>
                    Price<span className="text-danger"></span>
                  </label>
                  <div className="upload-input">
                    <input
                      type="number"
                      className="form-control"
                      name="price"
                      value={hospitalCharge.price}
                      onKeyPress={handkekeypreees}
                      onChange={addhospitalChare}
                    />
                  </div>
                </div>
                <div className="field-set">
                  <label>
                    Date<span className="text-danger"></span>
                  </label>
                  <div className="upload-input">
                    <input
                      type="date"
                      className="form-control"
                      name="date"
                      value={hospitalCharge.date || ""}
                      onChange={addhospitalChare}
                    />
                  </div>
                </div>
                <DialogActions className="submit-main">
                  {isEditT === true ? (
                    <Button
                      onClick={addchargeapiHedithspital}
                      variant="contained"
                    >
                      Edit Charge
                    </Button>
                  ) : (
                    <Button onClick={addchargeapiHospital} variant="contained">
                      Submit
                    </Button>
                  )}
                </DialogActions>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={openPharmacyModal}
          onClose={handleclickpcloseacycharge}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>{pharmacyadd === true ? "Edit" : "Add"} Pharmacy Charge</h6>
            </div>
            <div className="cross-icon" onClick={handleclickpcloseacycharge}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <div className="field-set">
                  <label>
                    Pharmacy Name<span className="text-danger"></span>
                  </label>
                  <div className="upload-input">
                    <input
                      type="text"
                      className="form-control"
                      name="service_name"
                      value={pharmacyvalue.service_name}
                      onChange={addhosppharmacyhare}
                    />
                  </div>
                </div>
                <div className="field-set">
                  <label>
                    Price<span className="text-danger"></span>
                  </label>
                  <div className="upload-input">
                    <input
                      type="number"
                      className="form-control"
                      name="price"
                      value={pharmacyvalue.price}
                      onKeyPress={handkekeypreees}
                      onChange={addhosppharmacyhare}
                    />
                  </div>
                </div>
                <div className="field-set">
                  <label>
                    Date<span className="text-danger"></span>
                  </label>
                  <div className="upload-input">
                    <input
                      type="date"
                      className="form-control"
                      name="date"
                      value={pharmacyvalue.date || ""}
                      onChange={addhosppharmacyhare}
                    />
                  </div>
                </div>
                <DialogActions className="submit-main">
                  {pharmacyadd === true ? (
                    <Button onClick={editpaharmacy} variant="contained">
                      Edit Charge
                    </Button>
                  ) : (
                    <Button onClick={addchargeapipharmacy} variant="contained">
                      Submit
                    </Button>
                  )}
                </DialogActions>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <React.Fragment>
        <Dialog
          fullWidth={fullWidth}
          maxWidth={maxWidth}
          open={notesModal}
          onClose={handleCloseNotesmodal}
        >
          <div className="main-card-header">
            <div className="note-hd">
              <h6>Edit Notes</h6>
            </div>
            <div className="cross-icon" onClick={handleCloseNotesmodal}>
              <i class="fa-solid fa-xmark"></i>
            </div>
          </div>
          <DialogContent className="main-box">
            <Box
              noValidate
              component="form"
              sx={{
                display: "flex",
                flexDirection: "column",
                width: "fit-content",
              }}
              className="contact-form"
            >
              <Box>
                <form id="contact-form" className="contact-form">
                  <div className="field-set">
                    <label>
                      Notes<span className="text-danger">*</span>
                    </label>
                    <div className="upload-input">
                      <input
                        type="text"
                        className="form-control"
                        name="note"
                        value={nodaestInput.note}
                        onChange={handlechangenotesdata}
                      />
                    </div>
                  </div>
                  <DialogActions className="submit-main">
                    <Button
                      type="submit"
                      onClick={(e) => handleKysDetailnotes(e)}
                      variant="contained"
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </form>
              </Box>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
    </>
  );
}
export default PatientDetail;
